@echo off
python "%~dp0wordpoints.py" %*
pause
