@echo off
python "%~dp0livingmusicengin0462.py" %*
pause
