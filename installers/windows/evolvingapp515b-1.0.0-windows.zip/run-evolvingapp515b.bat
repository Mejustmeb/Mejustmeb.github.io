@echo off
python "%~dp0evolvingapp515b.py" %*
pause
