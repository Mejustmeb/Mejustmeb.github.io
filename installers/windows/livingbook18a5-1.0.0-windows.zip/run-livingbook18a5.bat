@echo off
python "%~dp0livingbook18a5.py" %*
pause
