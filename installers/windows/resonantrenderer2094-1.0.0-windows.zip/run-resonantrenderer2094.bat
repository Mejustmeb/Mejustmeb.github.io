@echo off
python "%~dp0resonantrenderer2094.py" %*
pause
