@echo off
python "%~dp0resonantlanguage5913.py" %*
pause
