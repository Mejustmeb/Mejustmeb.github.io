@echo off
python "%~dp0evolvingapp466c.py" %*
pause
