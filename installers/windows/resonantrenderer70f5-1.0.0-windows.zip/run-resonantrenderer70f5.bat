@echo off
python "%~dp0resonantrenderer70f5.py" %*
pause
