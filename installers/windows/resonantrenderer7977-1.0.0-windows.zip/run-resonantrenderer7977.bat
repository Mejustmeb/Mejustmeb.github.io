@echo off
python "%~dp0resonantrenderer7977.py" %*
pause
