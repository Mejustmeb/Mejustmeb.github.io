@echo off
python "%~dp0evolvingapp8f3f.py" %*
pause
