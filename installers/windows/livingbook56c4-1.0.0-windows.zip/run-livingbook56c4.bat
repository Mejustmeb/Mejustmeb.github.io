@echo off
python "%~dp0livingbook56c4.py" %*
pause
