@echo off
python "%~dp0resonantlanguagece8d.py" %*
pause
