@echo off
python "%~dp0livingmusicengin9135.py" %*
pause
