@echo off
python "%~dp0resonantrendererfae4.py" %*
pause
