@echo off
python "%~dp0resonantlanguage0929.py" %*
pause
