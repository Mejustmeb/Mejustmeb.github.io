@echo off
python "%~dp0resonantlanguage3d5f.py" %*
pause
