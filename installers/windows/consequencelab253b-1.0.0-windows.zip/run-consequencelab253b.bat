@echo off
python "%~dp0consequencelab253b.py" %*
pause
