@echo off
python "%~dp0freewillgamedab6.py" %*
pause
