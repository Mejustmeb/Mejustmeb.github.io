@echo off
python "%~dp0selftuningcompre16ce.py" %*
pause
