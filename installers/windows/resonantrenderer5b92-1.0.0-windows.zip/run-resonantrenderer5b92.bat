@echo off
python "%~dp0resonantrenderer5b92.py" %*
pause
