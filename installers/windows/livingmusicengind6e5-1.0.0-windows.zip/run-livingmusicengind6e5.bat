@echo off
python "%~dp0livingmusicengind6e5.py" %*
pause
