@echo off
python "%~dp0evolvingappe806.py" %*
pause
