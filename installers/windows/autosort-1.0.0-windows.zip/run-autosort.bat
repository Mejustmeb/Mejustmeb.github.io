@echo off
python "%~dp0autosort.py" %*
pause
