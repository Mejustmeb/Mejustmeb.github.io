@echo off
python "%~dp0livingbook9c8f.py" %*
pause
