@echo off
python "%~dp0evolvingapp7730.py" %*
pause
