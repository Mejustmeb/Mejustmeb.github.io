@echo off
python "%~dp0evolvingapp00aa.py" %*
pause
