@echo off
python "%~dp0selftuningcomprea52d.py" %*
pause
