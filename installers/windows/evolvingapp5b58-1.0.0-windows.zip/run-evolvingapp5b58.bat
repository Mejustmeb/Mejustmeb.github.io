@echo off
python "%~dp0evolvingapp5b58.py" %*
pause
