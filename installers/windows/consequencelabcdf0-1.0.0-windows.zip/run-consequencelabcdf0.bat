@echo off
python "%~dp0consequencelabcdf0.py" %*
pause
