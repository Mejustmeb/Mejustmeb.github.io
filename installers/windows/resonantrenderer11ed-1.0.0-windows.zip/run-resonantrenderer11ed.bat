@echo off
python "%~dp0resonantrenderer11ed.py" %*
pause
