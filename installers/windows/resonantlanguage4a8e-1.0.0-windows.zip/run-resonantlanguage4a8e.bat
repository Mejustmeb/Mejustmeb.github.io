@echo off
python "%~dp0resonantlanguage4a8e.py" %*
pause
