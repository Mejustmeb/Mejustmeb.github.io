@echo off
python "%~dp0selftuningcompre4e7e.py" %*
pause
