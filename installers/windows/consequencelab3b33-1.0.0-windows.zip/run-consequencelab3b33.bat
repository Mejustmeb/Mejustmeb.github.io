@echo off
python "%~dp0consequencelab3b33.py" %*
pause
