@echo off
python "%~dp0resonantlanguageba7c.py" %*
pause
