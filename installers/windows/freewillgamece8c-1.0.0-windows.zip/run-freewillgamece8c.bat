@echo off
python "%~dp0freewillgamece8c.py" %*
pause
