@echo off
python "%~dp0livingmusicenginad0b.py" %*
pause
