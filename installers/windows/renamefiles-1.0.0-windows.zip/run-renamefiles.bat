@echo off
python "%~dp0renamefiles.py" %*
pause
