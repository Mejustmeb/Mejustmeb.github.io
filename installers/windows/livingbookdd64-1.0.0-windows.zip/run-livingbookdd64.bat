@echo off
python "%~dp0livingbookdd64.py" %*
pause
