@echo off
python "%~dp0backupfolders.py" %*
pause
