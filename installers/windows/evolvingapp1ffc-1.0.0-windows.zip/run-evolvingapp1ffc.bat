@echo off
python "%~dp0evolvingapp1ffc.py" %*
pause
