@echo off
python "%~dp0evolvingapp47d8.py" %*
pause
