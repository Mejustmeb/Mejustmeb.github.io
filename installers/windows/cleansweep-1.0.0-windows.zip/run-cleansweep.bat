@echo off
python "%~dp0cleansweep.py" %*
pause
