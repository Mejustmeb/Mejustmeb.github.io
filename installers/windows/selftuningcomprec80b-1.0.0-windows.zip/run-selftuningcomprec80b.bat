@echo off
python "%~dp0selftuningcomprec80b.py" %*
pause
