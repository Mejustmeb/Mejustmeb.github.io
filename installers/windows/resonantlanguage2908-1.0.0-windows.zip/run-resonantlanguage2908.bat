@echo off
python "%~dp0resonantlanguage2908.py" %*
pause
