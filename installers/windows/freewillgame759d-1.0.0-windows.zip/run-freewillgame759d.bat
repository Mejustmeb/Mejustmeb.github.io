@echo off
python "%~dp0freewillgame759d.py" %*
pause
