@echo off
python "%~dp0resonantrenderer1f00.py" %*
pause
