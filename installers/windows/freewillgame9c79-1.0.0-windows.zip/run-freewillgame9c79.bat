@echo off
python "%~dp0freewillgame9c79.py" %*
pause
