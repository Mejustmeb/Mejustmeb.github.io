@echo off
python "%~dp0freewillgame7ceb.py" %*
pause
