@echo off
python "%~dp0livingmusicenginef91.py" %*
pause
