@echo off
python "%~dp0freewillgamec319.py" %*
pause
