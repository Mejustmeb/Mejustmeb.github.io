@echo off
python "%~dp0selftuningcompre0671.py" %*
pause
