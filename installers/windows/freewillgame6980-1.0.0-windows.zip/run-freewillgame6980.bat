@echo off
python "%~dp0freewillgame6980.py" %*
pause
