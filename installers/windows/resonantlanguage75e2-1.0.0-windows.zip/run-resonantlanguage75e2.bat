@echo off
python "%~dp0resonantlanguage75e2.py" %*
pause
