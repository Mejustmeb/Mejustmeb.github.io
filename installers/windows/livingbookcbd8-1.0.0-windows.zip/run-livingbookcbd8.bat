@echo off
python "%~dp0livingbookcbd8.py" %*
pause
