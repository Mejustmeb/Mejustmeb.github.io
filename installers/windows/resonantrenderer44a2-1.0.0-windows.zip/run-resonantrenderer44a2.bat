@echo off
python "%~dp0resonantrenderer44a2.py" %*
pause
