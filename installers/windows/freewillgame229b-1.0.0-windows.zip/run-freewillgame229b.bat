@echo off
python "%~dp0freewillgame229b.py" %*
pause
