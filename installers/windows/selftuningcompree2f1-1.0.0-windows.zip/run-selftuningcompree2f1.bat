@echo off
python "%~dp0selftuningcompree2f1.py" %*
pause
