@echo off
python "%~dp0freewillgamed214.py" %*
pause
