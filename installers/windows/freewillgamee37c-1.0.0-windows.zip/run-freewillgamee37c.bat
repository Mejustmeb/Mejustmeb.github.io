@echo off
python "%~dp0freewillgamee37c.py" %*
pause
