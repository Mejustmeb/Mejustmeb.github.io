@echo off
python "%~dp0resonantlanguagec3db.py" %*
pause
