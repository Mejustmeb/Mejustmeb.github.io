@echo off
python "%~dp0freewillgame6ef5.py" %*
pause
