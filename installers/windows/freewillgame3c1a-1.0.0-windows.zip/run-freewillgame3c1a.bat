@echo off
python "%~dp0freewillgame3c1a.py" %*
pause
