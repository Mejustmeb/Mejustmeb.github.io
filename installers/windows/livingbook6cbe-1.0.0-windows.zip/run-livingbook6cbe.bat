@echo off
python "%~dp0livingbook6cbe.py" %*
pause
