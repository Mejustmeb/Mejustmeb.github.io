@echo off
python "%~dp0livingbook039b.py" %*
pause
