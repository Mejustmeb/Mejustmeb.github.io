@echo off
python "%~dp0evolvingappf284.py" %*
pause
