@echo off
python "%~dp0livingmusicengind9dc.py" %*
pause
