@echo off
python "%~dp0consequencelab0f2c.py" %*
pause
