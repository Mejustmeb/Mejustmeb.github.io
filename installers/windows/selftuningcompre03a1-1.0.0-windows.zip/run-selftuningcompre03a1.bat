@echo off
python "%~dp0selftuningcompre03a1.py" %*
pause
