@echo off
python "%~dp0consequencelab0b74.py" %*
pause
