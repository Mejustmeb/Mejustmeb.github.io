@echo off
python "%~dp0resonantrenderer6ebe.py" %*
pause
