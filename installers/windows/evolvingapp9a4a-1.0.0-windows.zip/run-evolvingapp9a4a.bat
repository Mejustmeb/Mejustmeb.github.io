@echo off
python "%~dp0evolvingapp9a4a.py" %*
pause
