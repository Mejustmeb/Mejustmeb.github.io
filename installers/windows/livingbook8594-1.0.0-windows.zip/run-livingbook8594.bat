@echo off
python "%~dp0livingbook8594.py" %*
pause
