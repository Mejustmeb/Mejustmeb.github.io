@echo off
python "%~dp0selftuningcompre885d.py" %*
pause
