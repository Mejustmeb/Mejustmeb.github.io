@echo off
python "%~dp0resonantlanguage6152.py" %*
pause
