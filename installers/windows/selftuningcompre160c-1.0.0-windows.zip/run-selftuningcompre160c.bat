@echo off
python "%~dp0selftuningcompre160c.py" %*
pause
