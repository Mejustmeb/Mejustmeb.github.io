@echo off
python "%~dp0selftuningcompree44b.py" %*
pause
