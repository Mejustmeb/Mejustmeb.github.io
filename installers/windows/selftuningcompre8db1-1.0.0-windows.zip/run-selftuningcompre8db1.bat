@echo off
python "%~dp0selftuningcompre8db1.py" %*
pause
