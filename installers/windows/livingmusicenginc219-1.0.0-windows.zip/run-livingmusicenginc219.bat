@echo off
python "%~dp0livingmusicenginc219.py" %*
pause
