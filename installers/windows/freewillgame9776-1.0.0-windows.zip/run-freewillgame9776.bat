@echo off
python "%~dp0freewillgame9776.py" %*
pause
