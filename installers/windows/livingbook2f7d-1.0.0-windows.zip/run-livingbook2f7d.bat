@echo off
python "%~dp0livingbook2f7d.py" %*
pause
