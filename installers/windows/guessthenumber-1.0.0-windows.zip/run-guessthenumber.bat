@echo off
python "%~dp0guessthenumber.py" %*
pause
