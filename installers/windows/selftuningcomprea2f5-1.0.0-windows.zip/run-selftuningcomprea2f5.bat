@echo off
python "%~dp0selftuningcomprea2f5.py" %*
pause
