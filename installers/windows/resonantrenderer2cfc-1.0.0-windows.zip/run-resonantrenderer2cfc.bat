@echo off
python "%~dp0resonantrenderer2cfc.py" %*
pause
