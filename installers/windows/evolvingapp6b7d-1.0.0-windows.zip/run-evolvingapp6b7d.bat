@echo off
python "%~dp0evolvingapp6b7d.py" %*
pause
