@echo off
python "%~dp0freewillgamef074.py" %*
pause
