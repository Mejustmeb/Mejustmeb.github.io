@echo off
python "%~dp0freewillgameec1d.py" %*
pause
