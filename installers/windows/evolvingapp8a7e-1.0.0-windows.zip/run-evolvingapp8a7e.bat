@echo off
python "%~dp0evolvingapp8a7e.py" %*
pause
