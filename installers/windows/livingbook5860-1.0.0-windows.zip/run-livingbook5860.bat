@echo off
python "%~dp0livingbook5860.py" %*
pause
