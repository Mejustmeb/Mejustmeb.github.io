@echo off
python "%~dp0selftuningcompre20cd.py" %*
pause
