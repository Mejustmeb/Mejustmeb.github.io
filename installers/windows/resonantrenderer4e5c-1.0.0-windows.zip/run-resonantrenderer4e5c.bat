@echo off
python "%~dp0resonantrenderer4e5c.py" %*
pause
