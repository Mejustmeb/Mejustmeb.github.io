@echo off
python "%~dp0selftuningcompree9a0.py" %*
pause
