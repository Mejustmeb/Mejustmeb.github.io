@echo off
python "%~dp0livingbookb587.py" %*
pause
