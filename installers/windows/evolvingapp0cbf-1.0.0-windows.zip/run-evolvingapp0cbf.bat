@echo off
python "%~dp0evolvingapp0cbf.py" %*
pause
