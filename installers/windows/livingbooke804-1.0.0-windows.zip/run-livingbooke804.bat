@echo off
python "%~dp0livingbooke804.py" %*
pause
