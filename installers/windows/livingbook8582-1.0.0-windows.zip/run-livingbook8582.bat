@echo off
python "%~dp0livingbook8582.py" %*
pause
