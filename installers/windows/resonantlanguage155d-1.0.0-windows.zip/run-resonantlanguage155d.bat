@echo off
python "%~dp0resonantlanguage155d.py" %*
pause
