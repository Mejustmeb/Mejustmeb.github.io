@echo off
python "%~dp0consequencelab05c7.py" %*
pause
