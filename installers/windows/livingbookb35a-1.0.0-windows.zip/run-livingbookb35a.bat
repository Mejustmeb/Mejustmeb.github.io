@echo off
python "%~dp0livingbookb35a.py" %*
pause
