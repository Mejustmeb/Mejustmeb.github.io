@echo off
python "%~dp0wordscramble.py" %*
pause
