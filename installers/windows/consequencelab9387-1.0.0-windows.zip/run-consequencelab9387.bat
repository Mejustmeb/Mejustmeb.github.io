@echo off
python "%~dp0consequencelab9387.py" %*
pause
