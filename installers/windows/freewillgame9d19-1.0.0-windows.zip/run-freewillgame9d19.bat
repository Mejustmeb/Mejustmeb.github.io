@echo off
python "%~dp0freewillgame9d19.py" %*
pause
