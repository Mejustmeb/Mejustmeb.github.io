@echo off
python "%~dp0livingbookc0e5.py" %*
pause
