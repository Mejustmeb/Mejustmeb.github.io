@echo off
python "%~dp0livingbook6513.py" %*
pause
