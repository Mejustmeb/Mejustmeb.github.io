@echo off
python "%~dp0resonantlanguage84ff.py" %*
pause
