@echo off
python "%~dp0evolvingapp8ca1.py" %*
pause
