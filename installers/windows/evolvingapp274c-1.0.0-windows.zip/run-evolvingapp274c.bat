@echo off
python "%~dp0evolvingapp274c.py" %*
pause
