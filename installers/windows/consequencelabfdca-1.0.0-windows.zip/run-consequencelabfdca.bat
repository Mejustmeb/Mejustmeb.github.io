@echo off
python "%~dp0consequencelabfdca.py" %*
pause
