@echo off
python "%~dp0resonantrenderer2d92.py" %*
pause
