@echo off
python "%~dp0resonantlanguage6156.py" %*
pause
