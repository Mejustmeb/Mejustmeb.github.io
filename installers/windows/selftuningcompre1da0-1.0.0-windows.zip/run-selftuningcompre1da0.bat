@echo off
python "%~dp0selftuningcompre1da0.py" %*
pause
