@echo off
python "%~dp0resonantrendererd499.py" %*
pause
