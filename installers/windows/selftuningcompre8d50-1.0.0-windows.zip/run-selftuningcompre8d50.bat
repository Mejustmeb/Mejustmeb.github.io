@echo off
python "%~dp0selftuningcompre8d50.py" %*
pause
