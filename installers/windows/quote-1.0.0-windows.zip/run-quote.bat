@echo off
python "%~dp0quote.py" %*
pause
