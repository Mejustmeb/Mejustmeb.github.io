@echo off
python "%~dp0resonantrenderer7650.py" %*
pause
