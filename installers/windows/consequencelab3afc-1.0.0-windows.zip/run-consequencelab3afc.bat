@echo off
python "%~dp0consequencelab3afc.py" %*
pause
