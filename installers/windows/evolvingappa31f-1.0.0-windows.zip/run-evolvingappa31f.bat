@echo off
python "%~dp0evolvingappa31f.py" %*
pause
