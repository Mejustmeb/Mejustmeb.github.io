@echo off
python "%~dp0evolvingapp5318.py" %*
pause
