@echo off
python "%~dp0selftuningcomprefda1.py" %*
pause
