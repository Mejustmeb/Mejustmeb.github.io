@echo off
python "%~dp0freewillgameb415.py" %*
pause
