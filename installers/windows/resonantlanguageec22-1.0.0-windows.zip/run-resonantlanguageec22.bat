@echo off
python "%~dp0resonantlanguageec22.py" %*
pause
