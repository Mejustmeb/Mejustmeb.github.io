@echo off
python "%~dp0consequencelababef.py" %*
pause
