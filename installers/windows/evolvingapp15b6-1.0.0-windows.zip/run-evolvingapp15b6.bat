@echo off
python "%~dp0evolvingapp15b6.py" %*
pause
