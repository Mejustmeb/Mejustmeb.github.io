@echo off
python "%~dp0evolvingapp48d0.py" %*
pause
