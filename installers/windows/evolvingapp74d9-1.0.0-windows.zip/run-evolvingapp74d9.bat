@echo off
python "%~dp0evolvingapp74d9.py" %*
pause
