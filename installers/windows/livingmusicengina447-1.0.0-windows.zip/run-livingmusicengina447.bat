@echo off
python "%~dp0livingmusicengina447.py" %*
pause
