@echo off
python "%~dp0evolvingapp2782.py" %*
pause
