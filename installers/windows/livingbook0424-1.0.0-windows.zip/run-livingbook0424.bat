@echo off
python "%~dp0livingbook0424.py" %*
pause
