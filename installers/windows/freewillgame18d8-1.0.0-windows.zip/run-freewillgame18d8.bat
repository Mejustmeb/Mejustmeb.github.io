@echo off
python "%~dp0freewillgame18d8.py" %*
pause
