@echo off
python "%~dp0resonantlanguagee046.py" %*
pause
