@echo off
python "%~dp0resonantlanguagecf4a.py" %*
pause
