@echo off
python "%~dp0freewillgameeeeb.py" %*
pause
