@echo off
python "%~dp0livingmusicengin693d.py" %*
pause
