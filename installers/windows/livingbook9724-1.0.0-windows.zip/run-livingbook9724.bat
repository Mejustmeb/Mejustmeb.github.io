@echo off
python "%~dp0livingbook9724.py" %*
pause
