@echo off
python "%~dp0selftuningcompre9431.py" %*
pause
