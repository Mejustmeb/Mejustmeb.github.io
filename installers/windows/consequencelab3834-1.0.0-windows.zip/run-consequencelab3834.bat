@echo off
python "%~dp0consequencelab3834.py" %*
pause
