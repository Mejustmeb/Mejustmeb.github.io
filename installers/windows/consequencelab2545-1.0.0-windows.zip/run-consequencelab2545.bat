@echo off
python "%~dp0consequencelab2545.py" %*
pause
