@echo off
python "%~dp0consequencelab3c47.py" %*
pause
