@echo off
python "%~dp0livingbookf76f.py" %*
pause
