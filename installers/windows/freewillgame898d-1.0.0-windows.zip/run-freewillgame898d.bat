@echo off
python "%~dp0freewillgame898d.py" %*
pause
