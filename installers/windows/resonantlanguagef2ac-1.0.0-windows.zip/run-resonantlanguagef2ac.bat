@echo off
python "%~dp0resonantlanguagef2ac.py" %*
pause
