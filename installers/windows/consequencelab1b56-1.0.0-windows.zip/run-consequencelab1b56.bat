@echo off
python "%~dp0consequencelab1b56.py" %*
pause
