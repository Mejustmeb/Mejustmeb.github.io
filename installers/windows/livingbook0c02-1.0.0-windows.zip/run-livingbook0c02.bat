@echo off
python "%~dp0livingbook0c02.py" %*
pause
