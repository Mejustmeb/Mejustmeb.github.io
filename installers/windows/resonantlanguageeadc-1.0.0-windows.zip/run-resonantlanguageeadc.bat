@echo off
python "%~dp0resonantlanguageeadc.py" %*
pause
