@echo off
python "%~dp0resonantlanguage73db.py" %*
pause
