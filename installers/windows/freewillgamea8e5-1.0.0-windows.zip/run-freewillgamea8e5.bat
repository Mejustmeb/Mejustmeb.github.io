@echo off
python "%~dp0freewillgamea8e5.py" %*
pause
