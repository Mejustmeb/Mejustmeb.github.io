@echo off
python "%~dp0consequencelab79b3.py" %*
pause
