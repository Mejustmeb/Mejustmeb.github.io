@echo off
python "%~dp0resonantlanguage21e2.py" %*
pause
