@echo off
python "%~dp0evolvingapp0e3e.py" %*
pause
