@echo off
python "%~dp0livingbook4c8d.py" %*
pause
