@echo off
python "%~dp0freewillgame4a44.py" %*
pause
