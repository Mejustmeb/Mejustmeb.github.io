@echo off
python "%~dp0livingbookeb05.py" %*
pause
