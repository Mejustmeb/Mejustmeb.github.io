@echo off
python "%~dp0textsearch.py" %*
pause
