@echo off
python "%~dp0freewillgame4d3e.py" %*
pause
