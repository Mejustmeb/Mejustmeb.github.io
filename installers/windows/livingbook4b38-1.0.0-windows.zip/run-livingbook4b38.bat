@echo off
python "%~dp0livingbook4b38.py" %*
pause
