@echo off
python "%~dp0freewillgameb4c5.py" %*
pause
