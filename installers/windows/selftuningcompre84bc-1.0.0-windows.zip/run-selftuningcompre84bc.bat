@echo off
python "%~dp0selftuningcompre84bc.py" %*
pause
