@echo off
python "%~dp0livingmusicengin3766.py" %*
pause
