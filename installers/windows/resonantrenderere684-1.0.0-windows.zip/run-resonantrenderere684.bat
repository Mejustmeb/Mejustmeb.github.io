@echo off
python "%~dp0resonantrenderere684.py" %*
pause
