@echo off
python "%~dp0selftuningcompre953c.py" %*
pause
