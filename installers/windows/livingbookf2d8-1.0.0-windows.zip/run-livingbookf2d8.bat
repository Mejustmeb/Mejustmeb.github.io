@echo off
python "%~dp0livingbookf2d8.py" %*
pause
