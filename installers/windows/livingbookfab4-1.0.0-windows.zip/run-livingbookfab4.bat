@echo off
python "%~dp0livingbookfab4.py" %*
pause
