@echo off
python "%~dp0freewillgamebd57.py" %*
pause
