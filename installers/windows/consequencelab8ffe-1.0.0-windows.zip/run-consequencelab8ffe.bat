@echo off
python "%~dp0consequencelab8ffe.py" %*
pause
