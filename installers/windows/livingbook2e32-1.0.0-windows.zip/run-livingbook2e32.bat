@echo off
python "%~dp0livingbook2e32.py" %*
pause
