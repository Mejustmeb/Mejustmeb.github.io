@echo off
python "%~dp0selftuningcompre7a02.py" %*
pause
