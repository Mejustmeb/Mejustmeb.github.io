@echo off
python "%~dp0consequencelabdba8.py" %*
pause
