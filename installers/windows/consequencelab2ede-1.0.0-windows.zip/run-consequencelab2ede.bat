@echo off
python "%~dp0consequencelab2ede.py" %*
pause
