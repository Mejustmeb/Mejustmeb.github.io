@echo off
python "%~dp0freewillgamed34d.py" %*
pause
