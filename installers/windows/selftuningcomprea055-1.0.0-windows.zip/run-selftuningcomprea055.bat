@echo off
python "%~dp0selftuningcomprea055.py" %*
pause
