@echo off
python "%~dp0evolvingapp8aaa.py" %*
pause
