@echo off
python "%~dp0resonantlanguage56a2.py" %*
pause
