@echo off
python "%~dp0mine3d.py" %*
pause
