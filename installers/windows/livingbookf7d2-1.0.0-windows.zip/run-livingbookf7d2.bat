@echo off
python "%~dp0livingbookf7d2.py" %*
pause
