@echo off
python "%~dp0resonantrenderer2fdb.py" %*
pause
