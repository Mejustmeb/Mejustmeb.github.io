@echo off
python "%~dp0livingbook9d87.py" %*
pause
