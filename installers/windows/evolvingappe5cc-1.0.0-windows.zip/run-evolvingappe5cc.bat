@echo off
python "%~dp0evolvingappe5cc.py" %*
pause
