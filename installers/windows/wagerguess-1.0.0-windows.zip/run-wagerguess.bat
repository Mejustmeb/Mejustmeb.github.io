@echo off
python "%~dp0wagerguess.py" %*
pause
