@echo off
python "%~dp0evolvingappc13e.py" %*
pause
