@echo off
python "%~dp0resonantrenderer3697.py" %*
pause
