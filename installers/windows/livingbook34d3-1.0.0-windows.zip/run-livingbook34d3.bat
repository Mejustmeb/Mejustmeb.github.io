@echo off
python "%~dp0livingbook34d3.py" %*
pause
