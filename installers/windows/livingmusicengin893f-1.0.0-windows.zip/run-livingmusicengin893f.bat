@echo off
python "%~dp0livingmusicengin893f.py" %*
pause
