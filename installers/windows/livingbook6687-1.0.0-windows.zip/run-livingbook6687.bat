@echo off
python "%~dp0livingbook6687.py" %*
pause
