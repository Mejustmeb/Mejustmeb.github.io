@echo off
python "%~dp0selftuningcomprea168.py" %*
pause
