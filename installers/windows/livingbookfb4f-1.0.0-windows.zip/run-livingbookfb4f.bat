@echo off
python "%~dp0livingbookfb4f.py" %*
pause
