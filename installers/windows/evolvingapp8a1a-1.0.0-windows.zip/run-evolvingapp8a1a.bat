@echo off
python "%~dp0evolvingapp8a1a.py" %*
pause
