@echo off
python "%~dp0consequencelabdc7a.py" %*
pause
