@echo off
python "%~dp0livingmusicenginb584.py" %*
pause
