@echo off
python "%~dp0consequencelabce5c.py" %*
pause
