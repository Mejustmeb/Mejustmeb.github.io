@echo off
python "%~dp0freewillgame5f44.py" %*
pause
