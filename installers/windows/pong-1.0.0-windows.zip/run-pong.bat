@echo off
python "%~dp0pong.py" %*
pause
