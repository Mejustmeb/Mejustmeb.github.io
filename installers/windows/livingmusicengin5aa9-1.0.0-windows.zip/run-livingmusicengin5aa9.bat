@echo off
python "%~dp0livingmusicengin5aa9.py" %*
pause
