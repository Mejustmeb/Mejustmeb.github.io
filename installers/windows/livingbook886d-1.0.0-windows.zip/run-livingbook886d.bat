@echo off
python "%~dp0livingbook886d.py" %*
pause
