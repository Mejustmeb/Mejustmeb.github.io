@echo off
python "%~dp0freewillgameb1b7.py" %*
pause
