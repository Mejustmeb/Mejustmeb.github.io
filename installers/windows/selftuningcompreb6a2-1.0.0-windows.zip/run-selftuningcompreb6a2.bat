@echo off
python "%~dp0selftuningcompreb6a2.py" %*
pause
