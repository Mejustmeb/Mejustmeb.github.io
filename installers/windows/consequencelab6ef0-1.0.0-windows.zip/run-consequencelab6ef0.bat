@echo off
python "%~dp0consequencelab6ef0.py" %*
pause
