@echo off
python "%~dp0thundurussmackingofh.py" %*
pause
