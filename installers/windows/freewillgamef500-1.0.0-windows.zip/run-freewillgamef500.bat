@echo off
python "%~dp0freewillgamef500.py" %*
pause
