@echo off
python "%~dp0freewillgame399a.py" %*
pause
