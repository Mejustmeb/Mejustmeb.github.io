@echo off
python "%~dp0freewillgame5b03.py" %*
pause
