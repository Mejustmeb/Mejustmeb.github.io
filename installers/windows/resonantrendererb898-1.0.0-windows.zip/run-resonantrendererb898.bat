@echo off
python "%~dp0resonantrendererb898.py" %*
pause
