@echo off
python "%~dp0evolvingappd73f.py" %*
pause
