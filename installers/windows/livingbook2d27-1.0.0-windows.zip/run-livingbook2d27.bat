@echo off
python "%~dp0livingbook2d27.py" %*
pause
