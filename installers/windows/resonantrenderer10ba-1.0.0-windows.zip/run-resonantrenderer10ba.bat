@echo off
python "%~dp0resonantrenderer10ba.py" %*
pause
