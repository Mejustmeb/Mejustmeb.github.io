@echo off
python "%~dp0freewillgamee96d.py" %*
pause
