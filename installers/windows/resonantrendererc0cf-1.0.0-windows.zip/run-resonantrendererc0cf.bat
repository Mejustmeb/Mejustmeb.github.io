@echo off
python "%~dp0resonantrendererc0cf.py" %*
pause
