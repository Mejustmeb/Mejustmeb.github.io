@echo off
python "%~dp0livingmusicengin6634.py" %*
pause
