@echo off
python "%~dp0livingmusicengine942.py" %*
pause
