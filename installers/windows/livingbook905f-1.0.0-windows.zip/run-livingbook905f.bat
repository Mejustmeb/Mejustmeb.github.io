@echo off
python "%~dp0livingbook905f.py" %*
pause
