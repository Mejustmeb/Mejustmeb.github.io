@echo off
python "%~dp0evolvingapp9ade.py" %*
pause
