@echo off
python "%~dp0selftuningcompred335.py" %*
pause
