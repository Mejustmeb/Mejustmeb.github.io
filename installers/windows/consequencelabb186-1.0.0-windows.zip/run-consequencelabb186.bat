@echo off
python "%~dp0consequencelabb186.py" %*
pause
