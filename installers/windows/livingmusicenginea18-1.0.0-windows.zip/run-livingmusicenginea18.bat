@echo off
python "%~dp0livingmusicenginea18.py" %*
pause
