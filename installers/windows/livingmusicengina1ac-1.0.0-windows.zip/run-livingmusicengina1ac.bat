@echo off
python "%~dp0livingmusicengina1ac.py" %*
pause
