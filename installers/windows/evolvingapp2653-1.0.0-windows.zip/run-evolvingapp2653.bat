@echo off
python "%~dp0evolvingapp2653.py" %*
pause
