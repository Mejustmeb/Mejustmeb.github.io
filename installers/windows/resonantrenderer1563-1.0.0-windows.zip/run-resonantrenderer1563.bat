@echo off
python "%~dp0resonantrenderer1563.py" %*
pause
