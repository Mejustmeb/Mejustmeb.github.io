@echo off
python "%~dp0resonantrenderer9d41.py" %*
pause
