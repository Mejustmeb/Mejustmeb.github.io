@echo off
python "%~dp0evolvingappae55.py" %*
pause
