@echo off
python "%~dp0freewillgame3703.py" %*
pause
