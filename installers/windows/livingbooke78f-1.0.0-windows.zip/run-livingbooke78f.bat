@echo off
python "%~dp0livingbooke78f.py" %*
pause
