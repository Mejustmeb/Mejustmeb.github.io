@echo off
python "%~dp0livingmusicengin7b30.py" %*
pause
