@echo off
python "%~dp0logsummarize.py" %*
pause
