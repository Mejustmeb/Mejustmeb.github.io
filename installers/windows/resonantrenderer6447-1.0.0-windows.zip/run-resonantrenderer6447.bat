@echo off
python "%~dp0resonantrenderer6447.py" %*
pause
