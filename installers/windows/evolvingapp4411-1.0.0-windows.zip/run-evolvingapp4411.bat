@echo off
python "%~dp0evolvingapp4411.py" %*
pause
