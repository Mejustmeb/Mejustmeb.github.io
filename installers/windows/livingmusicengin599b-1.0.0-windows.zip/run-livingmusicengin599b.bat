@echo off
python "%~dp0livingmusicengin599b.py" %*
pause
