@echo off
python "%~dp0resonantlanguagee988.py" %*
pause
