@echo off
python "%~dp0evolvingapp18ed.py" %*
pause
