@echo off
python "%~dp0resonantlanguage7245.py" %*
pause
