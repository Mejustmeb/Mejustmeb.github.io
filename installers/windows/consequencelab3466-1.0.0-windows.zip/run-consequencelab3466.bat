@echo off
python "%~dp0consequencelab3466.py" %*
pause
