@echo off
python "%~dp0freewillgame3803.py" %*
pause
