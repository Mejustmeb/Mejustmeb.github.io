@echo off
python "%~dp0resonantlanguage4002.py" %*
pause
