@echo off
python "%~dp0freewillgameb731.py" %*
pause
