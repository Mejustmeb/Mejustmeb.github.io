@echo off
python "%~dp0consequencelabb4d3.py" %*
pause
