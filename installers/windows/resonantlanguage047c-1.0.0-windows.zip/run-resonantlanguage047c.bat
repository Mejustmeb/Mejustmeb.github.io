@echo off
python "%~dp0resonantlanguage047c.py" %*
pause
