@echo off
python "%~dp0resonantlanguagef713.py" %*
pause
