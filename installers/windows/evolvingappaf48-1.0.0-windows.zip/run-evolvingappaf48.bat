@echo off
python "%~dp0evolvingappaf48.py" %*
pause
