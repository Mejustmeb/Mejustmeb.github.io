@echo off
python "%~dp0resonantlanguage5d64.py" %*
pause
