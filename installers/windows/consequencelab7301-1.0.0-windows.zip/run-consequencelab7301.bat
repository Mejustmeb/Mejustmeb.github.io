@echo off
python "%~dp0consequencelab7301.py" %*
pause
