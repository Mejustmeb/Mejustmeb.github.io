@echo off
python "%~dp0selftuningcompre5af5.py" %*
pause
