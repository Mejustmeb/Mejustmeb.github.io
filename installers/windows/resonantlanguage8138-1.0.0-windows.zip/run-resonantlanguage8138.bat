@echo off
python "%~dp0resonantlanguage8138.py" %*
pause
