@echo off
python "%~dp0selftuningcompre3fa8.py" %*
pause
