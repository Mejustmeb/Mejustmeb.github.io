@echo off
python "%~dp0selftuningcompre3458.py" %*
pause
