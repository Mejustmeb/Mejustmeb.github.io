@echo off
python "%~dp0evolvingappb67e.py" %*
pause
