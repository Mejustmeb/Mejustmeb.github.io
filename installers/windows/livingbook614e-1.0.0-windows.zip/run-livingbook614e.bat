@echo off
python "%~dp0livingbook614e.py" %*
pause
