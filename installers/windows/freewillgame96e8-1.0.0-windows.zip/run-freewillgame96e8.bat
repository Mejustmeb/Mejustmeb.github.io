@echo off
python "%~dp0freewillgame96e8.py" %*
pause
