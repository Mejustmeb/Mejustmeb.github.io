@echo off
python "%~dp0wordsprint.py" %*
pause
