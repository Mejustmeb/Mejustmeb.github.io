@echo off
python "%~dp0freewillgamea4d9.py" %*
pause
