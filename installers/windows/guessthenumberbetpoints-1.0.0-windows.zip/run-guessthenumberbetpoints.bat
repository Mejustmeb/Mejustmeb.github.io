@echo off
python "%~dp0guessthenumberbetpoints.py" %*
pause
