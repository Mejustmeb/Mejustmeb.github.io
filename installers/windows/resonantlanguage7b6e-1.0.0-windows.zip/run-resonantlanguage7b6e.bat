@echo off
python "%~dp0resonantlanguage7b6e.py" %*
pause
