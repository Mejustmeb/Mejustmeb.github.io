@echo off
python "%~dp0resonantlanguageac37.py" %*
pause
