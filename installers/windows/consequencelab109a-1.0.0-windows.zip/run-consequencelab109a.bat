@echo off
python "%~dp0consequencelab109a.py" %*
pause
