@echo off
python "%~dp0resonantlanguage0e8e.py" %*
pause
