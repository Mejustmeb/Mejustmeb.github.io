@echo off
python "%~dp0freewillgame2f4e.py" %*
pause
