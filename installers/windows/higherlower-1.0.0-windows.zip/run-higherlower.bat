@echo off
python "%~dp0higherlower.py" %*
pause
