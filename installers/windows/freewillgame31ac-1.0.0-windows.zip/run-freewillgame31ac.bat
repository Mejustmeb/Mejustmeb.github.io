@echo off
python "%~dp0freewillgame31ac.py" %*
pause
