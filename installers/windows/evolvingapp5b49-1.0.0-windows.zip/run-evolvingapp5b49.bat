@echo off
python "%~dp0evolvingapp5b49.py" %*
pause
