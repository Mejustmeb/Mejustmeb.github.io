@echo off
python "%~dp0consequencelab6d02.py" %*
pause
