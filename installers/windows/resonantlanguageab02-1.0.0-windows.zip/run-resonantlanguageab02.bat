@echo off
python "%~dp0resonantlanguageab02.py" %*
pause
