@echo off
python "%~dp0resonantrenderer7e6f.py" %*
pause
