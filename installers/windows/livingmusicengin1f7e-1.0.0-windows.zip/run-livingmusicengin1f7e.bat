@echo off
python "%~dp0livingmusicengin1f7e.py" %*
pause
