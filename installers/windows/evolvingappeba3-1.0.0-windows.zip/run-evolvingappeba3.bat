@echo off
python "%~dp0evolvingappeba3.py" %*
pause
