@echo off
python "%~dp0evolvingapp4c0d.py" %*
pause
