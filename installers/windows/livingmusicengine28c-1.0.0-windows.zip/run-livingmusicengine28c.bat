@echo off
python "%~dp0livingmusicengine28c.py" %*
pause
