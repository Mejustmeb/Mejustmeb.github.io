@echo off
python "%~dp0livingmusicengin8411.py" %*
pause
