@echo off
python "%~dp0lastletters.py" %*
pause
