@echo off
python "%~dp0livingbook76ab.py" %*
pause
