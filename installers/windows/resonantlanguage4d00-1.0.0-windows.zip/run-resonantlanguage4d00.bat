@echo off
python "%~dp0resonantlanguage4d00.py" %*
pause
