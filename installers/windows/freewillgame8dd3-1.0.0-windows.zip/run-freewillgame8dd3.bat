@echo off
python "%~dp0freewillgame8dd3.py" %*
pause
