@echo off
python "%~dp0freewillgame021e.py" %*
pause
