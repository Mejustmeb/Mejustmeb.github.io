@echo off
python "%~dp0freewillgame7479.py" %*
pause
