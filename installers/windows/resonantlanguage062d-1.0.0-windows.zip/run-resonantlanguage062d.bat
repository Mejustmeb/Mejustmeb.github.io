@echo off
python "%~dp0resonantlanguage062d.py" %*
pause
