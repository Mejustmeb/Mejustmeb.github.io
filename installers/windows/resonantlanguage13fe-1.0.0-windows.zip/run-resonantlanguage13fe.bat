@echo off
python "%~dp0resonantlanguage13fe.py" %*
pause
