@echo off
python "%~dp0evolvingappee25.py" %*
pause
