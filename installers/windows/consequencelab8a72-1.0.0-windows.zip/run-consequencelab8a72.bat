@echo off
python "%~dp0consequencelab8a72.py" %*
pause
