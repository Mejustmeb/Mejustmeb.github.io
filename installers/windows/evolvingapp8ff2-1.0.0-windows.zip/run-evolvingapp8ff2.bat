@echo off
python "%~dp0evolvingapp8ff2.py" %*
pause
