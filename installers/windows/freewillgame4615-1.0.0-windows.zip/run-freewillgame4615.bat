@echo off
python "%~dp0freewillgame4615.py" %*
pause
