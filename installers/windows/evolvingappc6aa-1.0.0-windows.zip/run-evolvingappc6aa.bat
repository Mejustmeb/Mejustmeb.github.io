@echo off
python "%~dp0evolvingappc6aa.py" %*
pause
