@echo off
python "%~dp0selftuningcompre6839.py" %*
pause
