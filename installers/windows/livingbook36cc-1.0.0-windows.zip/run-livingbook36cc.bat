@echo off
python "%~dp0livingbook36cc.py" %*
pause
