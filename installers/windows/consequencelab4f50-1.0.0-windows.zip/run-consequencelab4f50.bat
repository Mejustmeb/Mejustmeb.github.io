@echo off
python "%~dp0consequencelab4f50.py" %*
pause
