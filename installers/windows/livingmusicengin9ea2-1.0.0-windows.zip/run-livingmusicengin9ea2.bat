@echo off
python "%~dp0livingmusicengin9ea2.py" %*
pause
