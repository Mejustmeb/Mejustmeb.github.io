@echo off
python "%~dp0livingmusicenginf2c8.py" %*
pause
