@echo off
python "%~dp0freewillgame16c2.py" %*
pause
