@echo off
python "%~dp0haunterabroadofsojos.py" %*
pause
