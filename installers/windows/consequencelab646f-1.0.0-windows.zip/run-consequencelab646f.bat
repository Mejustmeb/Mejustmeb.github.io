@echo off
python "%~dp0consequencelab646f.py" %*
pause
