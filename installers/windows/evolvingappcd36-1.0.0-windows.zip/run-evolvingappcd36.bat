@echo off
python "%~dp0evolvingappcd36.py" %*
pause
