@echo off
python "%~dp0freewillgame08eb.py" %*
pause
