@echo off
python "%~dp0evolvingapp82fb.py" %*
pause
