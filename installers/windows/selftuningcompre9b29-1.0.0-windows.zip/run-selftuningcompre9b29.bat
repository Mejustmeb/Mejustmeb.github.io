@echo off
python "%~dp0selftuningcompre9b29.py" %*
pause
