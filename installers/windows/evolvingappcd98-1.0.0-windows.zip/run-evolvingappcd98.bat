@echo off
python "%~dp0evolvingappcd98.py" %*
pause
