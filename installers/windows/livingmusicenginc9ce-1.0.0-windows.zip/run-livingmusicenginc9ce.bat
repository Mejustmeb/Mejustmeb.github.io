@echo off
python "%~dp0livingmusicenginc9ce.py" %*
pause
