@echo off
python "%~dp0consequencelab0ddb.py" %*
pause
