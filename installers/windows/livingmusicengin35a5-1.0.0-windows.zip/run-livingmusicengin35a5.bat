@echo off
python "%~dp0livingmusicengin35a5.py" %*
pause
