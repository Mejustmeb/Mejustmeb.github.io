@echo off
python "%~dp0selftuningcomprea285.py" %*
pause
