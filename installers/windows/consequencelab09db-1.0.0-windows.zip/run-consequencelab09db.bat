@echo off
python "%~dp0consequencelab09db.py" %*
pause
