@echo off
python "%~dp0resonantlanguagee57d.py" %*
pause
