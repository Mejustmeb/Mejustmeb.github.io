@echo off
python "%~dp0consequencelabaded.py" %*
pause
