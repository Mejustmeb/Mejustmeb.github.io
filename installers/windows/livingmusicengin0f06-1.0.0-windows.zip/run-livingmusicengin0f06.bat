@echo off
python "%~dp0livingmusicengin0f06.py" %*
pause
