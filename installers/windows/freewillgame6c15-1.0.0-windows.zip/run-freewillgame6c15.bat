@echo off
python "%~dp0freewillgame6c15.py" %*
pause
