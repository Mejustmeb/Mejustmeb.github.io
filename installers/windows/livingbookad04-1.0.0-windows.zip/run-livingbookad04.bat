@echo off
python "%~dp0livingbookad04.py" %*
pause
