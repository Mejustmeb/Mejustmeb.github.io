@echo off
python "%~dp0freewillgame1c30.py" %*
pause
