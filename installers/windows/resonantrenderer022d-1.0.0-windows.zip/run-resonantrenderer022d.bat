@echo off
python "%~dp0resonantrenderer022d.py" %*
pause
