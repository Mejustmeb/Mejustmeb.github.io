@echo off
python "%~dp0livingmusicengin1d46.py" %*
pause
