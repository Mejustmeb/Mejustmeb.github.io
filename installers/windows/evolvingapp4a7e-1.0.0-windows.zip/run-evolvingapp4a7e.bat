@echo off
python "%~dp0evolvingapp4a7e.py" %*
pause
