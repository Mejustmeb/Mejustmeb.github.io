@echo off
python "%~dp0freewillgame470d.py" %*
pause
