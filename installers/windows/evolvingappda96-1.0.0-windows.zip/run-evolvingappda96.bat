@echo off
python "%~dp0evolvingappda96.py" %*
pause
