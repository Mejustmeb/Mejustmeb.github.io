@echo off
python "%~dp0resonantrendererc67f.py" %*
pause
