@echo off
python "%~dp0consequencelab0ae2.py" %*
pause
