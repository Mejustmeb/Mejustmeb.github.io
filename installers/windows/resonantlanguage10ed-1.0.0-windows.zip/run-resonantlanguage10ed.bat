@echo off
python "%~dp0resonantlanguage10ed.py" %*
pause
