@echo off
python "%~dp0livingbook4263.py" %*
pause
