@echo off
python "%~dp0selftuningcompre17f7.py" %*
pause
