@echo off
python "%~dp0resonantlanguagef30f.py" %*
pause
