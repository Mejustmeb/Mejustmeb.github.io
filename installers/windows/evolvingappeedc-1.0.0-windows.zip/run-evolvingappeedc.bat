@echo off
python "%~dp0evolvingappeedc.py" %*
pause
