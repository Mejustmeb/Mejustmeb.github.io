@echo off
python "%~dp0livingbookb225.py" %*
pause
