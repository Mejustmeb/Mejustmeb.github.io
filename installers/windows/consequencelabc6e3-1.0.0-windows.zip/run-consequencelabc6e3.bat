@echo off
python "%~dp0consequencelabc6e3.py" %*
pause
