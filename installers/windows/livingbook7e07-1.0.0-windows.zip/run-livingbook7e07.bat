@echo off
python "%~dp0livingbook7e07.py" %*
pause
