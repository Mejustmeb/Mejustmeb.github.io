@echo off
python "%~dp0livingbooka251.py" %*
pause
