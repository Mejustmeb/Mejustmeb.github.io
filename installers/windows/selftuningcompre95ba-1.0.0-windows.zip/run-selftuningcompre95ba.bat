@echo off
python "%~dp0selftuningcompre95ba.py" %*
pause
