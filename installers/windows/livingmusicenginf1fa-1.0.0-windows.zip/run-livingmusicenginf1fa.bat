@echo off
python "%~dp0livingmusicenginf1fa.py" %*
pause
