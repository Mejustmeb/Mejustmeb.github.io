@echo off
python "%~dp0consequencelab9f7c.py" %*
pause
