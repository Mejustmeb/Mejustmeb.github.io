@echo off
python "%~dp0resonantlanguage43d9.py" %*
pause
