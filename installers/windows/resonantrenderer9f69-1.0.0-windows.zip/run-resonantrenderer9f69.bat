@echo off
python "%~dp0resonantrenderer9f69.py" %*
pause
