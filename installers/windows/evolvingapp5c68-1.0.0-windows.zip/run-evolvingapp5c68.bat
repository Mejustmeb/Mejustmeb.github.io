@echo off
python "%~dp0evolvingapp5c68.py" %*
pause
