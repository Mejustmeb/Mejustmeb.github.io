@echo off
python "%~dp0selftuningcompre0dc9.py" %*
pause
