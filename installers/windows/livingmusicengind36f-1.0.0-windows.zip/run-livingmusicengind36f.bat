@echo off
python "%~dp0livingmusicengind36f.py" %*
pause
