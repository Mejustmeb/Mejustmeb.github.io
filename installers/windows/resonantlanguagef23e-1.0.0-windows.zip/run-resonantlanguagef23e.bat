@echo off
python "%~dp0resonantlanguagef23e.py" %*
pause
