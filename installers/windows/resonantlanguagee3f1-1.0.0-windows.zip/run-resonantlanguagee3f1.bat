@echo off
python "%~dp0resonantlanguagee3f1.py" %*
pause
