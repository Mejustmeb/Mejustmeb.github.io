@echo off
python "%~dp0resonantlanguageacf4.py" %*
pause
