@echo off
python "%~dp0resonantlanguage260e.py" %*
pause
