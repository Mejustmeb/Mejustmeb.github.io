@echo off
python "%~dp0findtext.py" %*
pause
