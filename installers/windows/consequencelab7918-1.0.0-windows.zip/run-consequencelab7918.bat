@echo off
python "%~dp0consequencelab7918.py" %*
pause
