@echo off
python "%~dp0livingmusicengin4673.py" %*
pause
