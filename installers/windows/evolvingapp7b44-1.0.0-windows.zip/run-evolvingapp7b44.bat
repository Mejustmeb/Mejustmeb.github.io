@echo off
python "%~dp0evolvingapp7b44.py" %*
pause
