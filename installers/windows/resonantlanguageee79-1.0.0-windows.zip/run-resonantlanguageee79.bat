@echo off
python "%~dp0resonantlanguageee79.py" %*
pause
