@echo off
python "%~dp0resonantrenderera1b9.py" %*
pause
