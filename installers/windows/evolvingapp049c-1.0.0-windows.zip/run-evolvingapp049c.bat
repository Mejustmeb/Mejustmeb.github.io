@echo off
python "%~dp0evolvingapp049c.py" %*
pause
