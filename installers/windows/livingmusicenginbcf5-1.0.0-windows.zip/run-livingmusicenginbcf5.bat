@echo off
python "%~dp0livingmusicenginbcf5.py" %*
pause
