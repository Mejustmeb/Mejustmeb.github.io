@echo off
python "%~dp0resonantlanguagee13a.py" %*
pause
