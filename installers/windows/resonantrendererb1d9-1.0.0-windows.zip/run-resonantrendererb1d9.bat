@echo off
python "%~dp0resonantrendererb1d9.py" %*
pause
