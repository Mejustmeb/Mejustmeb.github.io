@echo off
python "%~dp0livingbookd710.py" %*
pause
