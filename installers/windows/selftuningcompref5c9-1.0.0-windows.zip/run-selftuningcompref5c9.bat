@echo off
python "%~dp0selftuningcompref5c9.py" %*
pause
