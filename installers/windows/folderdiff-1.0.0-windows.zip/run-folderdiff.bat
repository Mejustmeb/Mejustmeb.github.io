@echo off
python "%~dp0folderdiff.py" %*
pause
