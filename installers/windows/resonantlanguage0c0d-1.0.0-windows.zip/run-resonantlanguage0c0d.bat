@echo off
python "%~dp0resonantlanguage0c0d.py" %*
pause
