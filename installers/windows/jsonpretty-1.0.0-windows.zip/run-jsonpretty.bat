@echo off
python "%~dp0jsonpretty.py" %*
pause
