@echo off
python "%~dp0livingmusicengin12c3.py" %*
pause
