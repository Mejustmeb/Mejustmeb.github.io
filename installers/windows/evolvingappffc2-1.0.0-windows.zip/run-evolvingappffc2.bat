@echo off
python "%~dp0evolvingappffc2.py" %*
pause
