@echo off
python "%~dp0resonantlanguage2594.py" %*
pause
