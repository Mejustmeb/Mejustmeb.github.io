@echo off
python "%~dp0resonantrenderera0a0.py" %*
pause
