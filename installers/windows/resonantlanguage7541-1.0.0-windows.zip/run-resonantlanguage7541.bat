@echo off
python "%~dp0resonantlanguage7541.py" %*
pause
