@echo off
python "%~dp0freewillgame12a6.py" %*
pause
