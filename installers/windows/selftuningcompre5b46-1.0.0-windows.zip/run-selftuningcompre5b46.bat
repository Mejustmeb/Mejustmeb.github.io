@echo off
python "%~dp0selftuningcompre5b46.py" %*
pause
