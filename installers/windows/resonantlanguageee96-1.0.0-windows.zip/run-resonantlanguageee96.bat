@echo off
python "%~dp0resonantlanguageee96.py" %*
pause
