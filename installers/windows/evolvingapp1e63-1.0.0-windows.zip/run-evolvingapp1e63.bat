@echo off
python "%~dp0evolvingapp1e63.py" %*
pause
