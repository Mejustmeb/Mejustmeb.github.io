@echo off
python "%~dp0evolvingappe18e.py" %*
pause
