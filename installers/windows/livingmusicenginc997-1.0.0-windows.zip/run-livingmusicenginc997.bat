@echo off
python "%~dp0livingmusicenginc997.py" %*
pause
