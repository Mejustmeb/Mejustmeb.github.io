@echo off
python "%~dp0consequencelab18c0.py" %*
pause
