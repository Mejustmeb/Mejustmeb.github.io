@echo off
python "%~dp0consequencelabe64b.py" %*
pause
