@echo off
python "%~dp0evolvingappbf3a.py" %*
pause
