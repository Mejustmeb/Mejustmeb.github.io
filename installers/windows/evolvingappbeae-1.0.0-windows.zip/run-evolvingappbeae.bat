@echo off
python "%~dp0evolvingappbeae.py" %*
pause
