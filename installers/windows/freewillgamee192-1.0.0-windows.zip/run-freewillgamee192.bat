@echo off
python "%~dp0freewillgamee192.py" %*
pause
