@echo off
python "%~dp0consequencelabae88.py" %*
pause
