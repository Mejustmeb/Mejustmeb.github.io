@echo off
python "%~dp0livingbook9646.py" %*
pause
