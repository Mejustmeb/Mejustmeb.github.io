@echo off
python "%~dp0resonantlanguage2221.py" %*
pause
