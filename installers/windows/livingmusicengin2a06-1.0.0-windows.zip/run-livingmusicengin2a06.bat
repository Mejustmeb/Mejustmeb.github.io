@echo off
python "%~dp0livingmusicengin2a06.py" %*
pause
