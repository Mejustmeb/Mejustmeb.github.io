@echo off
python "%~dp0resonantrenderer0b71.py" %*
pause
