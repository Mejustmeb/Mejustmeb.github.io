@echo off
python "%~dp0evolvingappa978.py" %*
pause
