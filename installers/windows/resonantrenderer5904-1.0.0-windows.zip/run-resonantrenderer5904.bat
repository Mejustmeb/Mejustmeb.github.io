@echo off
python "%~dp0resonantrenderer5904.py" %*
pause
