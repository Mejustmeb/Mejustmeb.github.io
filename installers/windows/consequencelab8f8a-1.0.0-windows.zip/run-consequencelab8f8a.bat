@echo off
python "%~dp0consequencelab8f8a.py" %*
pause
