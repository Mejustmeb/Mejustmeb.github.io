@echo off
python "%~dp0resonantrenderer2dcf.py" %*
pause
