@echo off
python "%~dp0consequencelab1715.py" %*
pause
