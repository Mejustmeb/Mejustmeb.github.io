@echo off
python "%~dp0livingbook0828.py" %*
pause
