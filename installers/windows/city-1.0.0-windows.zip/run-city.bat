@echo off
python "%~dp0city.py" %*
pause
