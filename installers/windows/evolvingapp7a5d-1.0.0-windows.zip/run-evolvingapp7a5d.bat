@echo off
python "%~dp0evolvingapp7a5d.py" %*
pause
