@echo off
python "%~dp0selftuningcompre154f.py" %*
pause
