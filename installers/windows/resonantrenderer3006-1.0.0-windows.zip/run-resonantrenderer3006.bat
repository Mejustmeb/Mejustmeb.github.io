@echo off
python "%~dp0resonantrenderer3006.py" %*
pause
