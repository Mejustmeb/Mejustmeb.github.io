@echo off
python "%~dp0livingbook561f.py" %*
pause
