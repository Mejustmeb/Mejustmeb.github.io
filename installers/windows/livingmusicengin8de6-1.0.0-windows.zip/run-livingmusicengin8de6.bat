@echo off
python "%~dp0livingmusicengin8de6.py" %*
pause
