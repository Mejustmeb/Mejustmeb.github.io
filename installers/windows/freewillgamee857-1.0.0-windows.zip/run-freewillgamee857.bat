@echo off
python "%~dp0freewillgamee857.py" %*
pause
