@echo off
python "%~dp0consequencelab9726.py" %*
pause
