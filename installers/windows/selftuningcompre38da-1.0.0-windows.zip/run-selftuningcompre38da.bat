@echo off
python "%~dp0selftuningcompre38da.py" %*
pause
