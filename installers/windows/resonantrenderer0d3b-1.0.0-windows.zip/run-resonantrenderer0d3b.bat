@echo off
python "%~dp0resonantrenderer0d3b.py" %*
pause
