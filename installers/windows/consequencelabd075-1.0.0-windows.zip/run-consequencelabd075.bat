@echo off
python "%~dp0consequencelabd075.py" %*
pause
