@echo off
python "%~dp0evolvingapp4d4a.py" %*
pause
