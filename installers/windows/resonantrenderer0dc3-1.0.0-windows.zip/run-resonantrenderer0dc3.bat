@echo off
python "%~dp0resonantrenderer0dc3.py" %*
pause
