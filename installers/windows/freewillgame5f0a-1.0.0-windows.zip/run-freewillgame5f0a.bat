@echo off
python "%~dp0freewillgame5f0a.py" %*
pause
