@echo off
python "%~dp0resonantrenderer973e.py" %*
pause
