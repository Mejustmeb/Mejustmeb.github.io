@echo off
python "%~dp0livingbookf9ae.py" %*
pause
