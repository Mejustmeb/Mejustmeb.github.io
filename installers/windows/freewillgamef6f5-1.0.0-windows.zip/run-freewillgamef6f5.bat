@echo off
python "%~dp0freewillgamef6f5.py" %*
pause
