@echo off
python "%~dp0freewillgame171d.py" %*
pause
