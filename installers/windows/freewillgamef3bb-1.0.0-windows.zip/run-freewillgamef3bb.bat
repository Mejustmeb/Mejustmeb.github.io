@echo off
python "%~dp0freewillgamef3bb.py" %*
pause
