@echo off
python "%~dp0selftuningcompre3906.py" %*
pause
