@echo off
python "%~dp0rollthediceearnpoints.py" %*
pause
