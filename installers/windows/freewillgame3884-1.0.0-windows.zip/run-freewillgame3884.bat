@echo off
python "%~dp0freewillgame3884.py" %*
pause
