@echo off
python "%~dp0resonantrendererc184.py" %*
pause
