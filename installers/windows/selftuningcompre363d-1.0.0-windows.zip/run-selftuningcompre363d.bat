@echo off
python "%~dp0selftuningcompre363d.py" %*
pause
