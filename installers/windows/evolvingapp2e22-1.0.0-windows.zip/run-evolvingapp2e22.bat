@echo off
python "%~dp0evolvingapp2e22.py" %*
pause
