@echo off
python "%~dp0evolvingapp3e2c.py" %*
pause
