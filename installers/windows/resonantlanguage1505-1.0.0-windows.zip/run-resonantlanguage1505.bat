@echo off
python "%~dp0resonantlanguage1505.py" %*
pause
