@echo off
python "%~dp0evolvingapp2288.py" %*
pause
