@echo off
python "%~dp0consequencelabb4bd.py" %*
pause
