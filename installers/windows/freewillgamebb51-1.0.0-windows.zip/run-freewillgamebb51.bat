@echo off
python "%~dp0freewillgamebb51.py" %*
pause
