@echo off
python "%~dp0consequencelab5b3c.py" %*
pause
