@echo off
python "%~dp0livingmusicengin3254.py" %*
pause
