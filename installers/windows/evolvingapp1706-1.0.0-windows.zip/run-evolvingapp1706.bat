@echo off
python "%~dp0evolvingapp1706.py" %*
pause
