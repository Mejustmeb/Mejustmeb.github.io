@echo off
python "%~dp0resonantrendererabd0.py" %*
pause
