@echo off
python "%~dp0resonantlanguagee7e3.py" %*
pause
