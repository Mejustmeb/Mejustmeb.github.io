@echo off
python "%~dp0resonantrendererda72.py" %*
pause
