@echo off
python "%~dp0consequencelab52ec.py" %*
pause
