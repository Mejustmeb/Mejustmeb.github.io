@echo off
python "%~dp0livingmusicenginc0d4.py" %*
pause
