@echo off
python "%~dp0evolvingappe37e.py" %*
pause
