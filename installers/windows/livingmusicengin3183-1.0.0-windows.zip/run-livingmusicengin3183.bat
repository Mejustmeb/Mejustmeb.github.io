@echo off
python "%~dp0livingmusicengin3183.py" %*
pause
