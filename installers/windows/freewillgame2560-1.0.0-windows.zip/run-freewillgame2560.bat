@echo off
python "%~dp0freewillgame2560.py" %*
pause
