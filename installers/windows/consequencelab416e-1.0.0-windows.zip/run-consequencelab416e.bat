@echo off
python "%~dp0consequencelab416e.py" %*
pause
