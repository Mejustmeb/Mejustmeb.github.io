@echo off
python "%~dp0freewillgameebc5.py" %*
pause
