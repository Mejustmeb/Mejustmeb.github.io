@echo off
python "%~dp0selftuningcomprec89e.py" %*
pause
