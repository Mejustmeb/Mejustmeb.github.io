@echo off
python "%~dp0resonantlanguagef48c.py" %*
pause
