@echo off
python "%~dp0evolvingapp5906.py" %*
pause
