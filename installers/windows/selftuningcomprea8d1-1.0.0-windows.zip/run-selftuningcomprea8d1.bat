@echo off
python "%~dp0selftuningcomprea8d1.py" %*
pause
