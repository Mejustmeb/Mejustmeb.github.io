@echo off
python "%~dp0livingbooka76e.py" %*
pause
