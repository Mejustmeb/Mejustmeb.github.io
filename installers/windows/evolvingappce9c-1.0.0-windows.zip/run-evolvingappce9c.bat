@echo off
python "%~dp0evolvingappce9c.py" %*
pause
