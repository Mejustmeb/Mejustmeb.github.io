@echo off
python "%~dp0resonantlanguagedddb.py" %*
pause
