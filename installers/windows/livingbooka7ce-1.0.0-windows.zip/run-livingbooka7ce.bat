@echo off
python "%~dp0livingbooka7ce.py" %*
pause
