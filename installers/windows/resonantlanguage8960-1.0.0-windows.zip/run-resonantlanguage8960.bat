@echo off
python "%~dp0resonantlanguage8960.py" %*
pause
