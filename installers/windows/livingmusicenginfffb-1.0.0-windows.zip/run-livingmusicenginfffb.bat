@echo off
python "%~dp0livingmusicenginfffb.py" %*
pause
