@echo off
python "%~dp0blackjack.py" %*
pause
