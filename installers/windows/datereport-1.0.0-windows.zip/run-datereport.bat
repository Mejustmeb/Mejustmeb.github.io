@echo off
python "%~dp0datereport.py" %*
pause
