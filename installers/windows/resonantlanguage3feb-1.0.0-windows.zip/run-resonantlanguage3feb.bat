@echo off
python "%~dp0resonantlanguage3feb.py" %*
pause
