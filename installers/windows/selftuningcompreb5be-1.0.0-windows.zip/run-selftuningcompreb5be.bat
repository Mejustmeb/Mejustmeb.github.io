@echo off
python "%~dp0selftuningcompreb5be.py" %*
pause
