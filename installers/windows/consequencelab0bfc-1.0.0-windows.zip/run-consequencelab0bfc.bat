@echo off
python "%~dp0consequencelab0bfc.py" %*
pause
