@echo off
python "%~dp0selftuningcompre1f2e.py" %*
pause
