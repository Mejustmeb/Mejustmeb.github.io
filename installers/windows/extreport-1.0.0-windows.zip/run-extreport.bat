@echo off
python "%~dp0extreport.py" %*
pause
