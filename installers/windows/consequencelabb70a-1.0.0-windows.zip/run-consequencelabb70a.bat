@echo off
python "%~dp0consequencelabb70a.py" %*
pause
