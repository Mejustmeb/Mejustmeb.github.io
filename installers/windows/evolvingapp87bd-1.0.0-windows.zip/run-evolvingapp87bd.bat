@echo off
python "%~dp0evolvingapp87bd.py" %*
pause
