@echo off
python "%~dp0livingbook538e.py" %*
pause
