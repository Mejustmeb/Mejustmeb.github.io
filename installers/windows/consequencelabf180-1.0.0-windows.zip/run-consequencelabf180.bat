@echo off
python "%~dp0consequencelabf180.py" %*
pause
