@echo off
python "%~dp0resonantrenderer8f52.py" %*
pause
