@echo off
python "%~dp0livingbook568d.py" %*
pause
