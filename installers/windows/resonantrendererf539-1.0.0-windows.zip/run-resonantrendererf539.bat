@echo off
python "%~dp0resonantrendererf539.py" %*
pause
