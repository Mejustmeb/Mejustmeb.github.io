@echo off
python "%~dp0livingmusicengin0610.py" %*
pause
