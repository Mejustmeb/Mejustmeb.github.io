@echo off
python "%~dp0evolvingapp065a.py" %*
pause
