@echo off
python "%~dp0resonantrenderercb7a.py" %*
pause
