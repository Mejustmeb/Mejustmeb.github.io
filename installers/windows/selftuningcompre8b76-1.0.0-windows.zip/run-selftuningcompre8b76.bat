@echo off
python "%~dp0selftuningcompre8b76.py" %*
pause
