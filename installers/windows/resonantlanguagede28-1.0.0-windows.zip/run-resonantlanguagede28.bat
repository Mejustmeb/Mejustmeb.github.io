@echo off
python "%~dp0resonantlanguagede28.py" %*
pause
