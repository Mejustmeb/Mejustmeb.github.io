@echo off
python "%~dp0evolvingappdb5b.py" %*
pause
