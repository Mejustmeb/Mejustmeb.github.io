@echo off
python "%~dp0consequencelab308e.py" %*
pause
