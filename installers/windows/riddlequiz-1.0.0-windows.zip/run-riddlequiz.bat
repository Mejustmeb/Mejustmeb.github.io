@echo off
python "%~dp0riddlequiz.py" %*
pause
