@echo off
python "%~dp0livingmusicengin15b0.py" %*
pause
