@echo off
python "%~dp0livingbookc341.py" %*
pause
