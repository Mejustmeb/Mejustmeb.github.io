@echo off
python "%~dp0resonantrenderer4d48.py" %*
pause
