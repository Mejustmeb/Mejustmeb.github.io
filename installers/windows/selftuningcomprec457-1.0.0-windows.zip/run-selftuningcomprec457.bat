@echo off
python "%~dp0selftuningcomprec457.py" %*
pause
