@echo off
python "%~dp0resonantlanguagec3c0.py" %*
pause
