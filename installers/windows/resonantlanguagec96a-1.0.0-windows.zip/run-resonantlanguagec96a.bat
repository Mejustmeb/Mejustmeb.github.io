@echo off
python "%~dp0resonantlanguagec96a.py" %*
pause
