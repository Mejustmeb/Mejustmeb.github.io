@echo off
python "%~dp0freewillgame7730.py" %*
pause
