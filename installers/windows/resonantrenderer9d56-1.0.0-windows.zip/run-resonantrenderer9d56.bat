@echo off
python "%~dp0resonantrenderer9d56.py" %*
pause
