@echo off
python "%~dp0resonantrendererada1.py" %*
pause
