@echo off
python "%~dp0selftuningcomprebe3f.py" %*
pause
