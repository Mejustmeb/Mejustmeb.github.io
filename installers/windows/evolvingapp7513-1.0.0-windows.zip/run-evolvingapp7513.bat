@echo off
python "%~dp0evolvingapp7513.py" %*
pause
