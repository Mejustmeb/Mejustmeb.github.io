@echo off
python "%~dp0livingmusicenginc223.py" %*
pause
