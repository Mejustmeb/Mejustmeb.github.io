@echo off
python "%~dp0evolvingapp1569.py" %*
pause
