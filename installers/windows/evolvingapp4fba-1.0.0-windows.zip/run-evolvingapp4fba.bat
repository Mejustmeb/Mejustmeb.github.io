@echo off
python "%~dp0evolvingapp4fba.py" %*
pause
