@echo off
python "%~dp0freewillgame79ee.py" %*
pause
