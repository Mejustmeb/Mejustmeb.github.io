@echo off
python "%~dp0evolvingapp45c1.py" %*
pause
