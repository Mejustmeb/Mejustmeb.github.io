@echo off
python "%~dp0resonantrenderer90a2.py" %*
pause
