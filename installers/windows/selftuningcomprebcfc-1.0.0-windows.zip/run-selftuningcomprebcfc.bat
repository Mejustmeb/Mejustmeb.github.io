@echo off
python "%~dp0selftuningcomprebcfc.py" %*
pause
