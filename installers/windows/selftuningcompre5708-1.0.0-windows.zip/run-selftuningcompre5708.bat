@echo off
python "%~dp0selftuningcompre5708.py" %*
pause
