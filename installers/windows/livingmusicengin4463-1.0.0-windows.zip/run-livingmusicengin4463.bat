@echo off
python "%~dp0livingmusicengin4463.py" %*
pause
