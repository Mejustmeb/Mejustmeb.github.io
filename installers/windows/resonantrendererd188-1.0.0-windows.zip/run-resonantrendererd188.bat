@echo off
python "%~dp0resonantrendererd188.py" %*
pause
