@echo off
python "%~dp0evolvingapp31c9.py" %*
pause
