@echo off
python "%~dp0livingbook0120.py" %*
pause
