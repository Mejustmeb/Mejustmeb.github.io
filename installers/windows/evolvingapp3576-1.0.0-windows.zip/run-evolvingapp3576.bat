@echo off
python "%~dp0evolvingapp3576.py" %*
pause
