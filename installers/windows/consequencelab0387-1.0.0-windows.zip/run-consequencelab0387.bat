@echo off
python "%~dp0consequencelab0387.py" %*
pause
