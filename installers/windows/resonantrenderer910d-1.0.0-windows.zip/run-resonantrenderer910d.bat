@echo off
python "%~dp0resonantrenderer910d.py" %*
pause
