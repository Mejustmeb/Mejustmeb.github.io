@echo off
python "%~dp0selftuningcompre51e1.py" %*
pause
