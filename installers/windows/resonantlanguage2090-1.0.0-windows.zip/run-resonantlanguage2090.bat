@echo off
python "%~dp0resonantlanguage2090.py" %*
pause
