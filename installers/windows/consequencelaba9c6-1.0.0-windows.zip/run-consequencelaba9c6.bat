@echo off
python "%~dp0consequencelaba9c6.py" %*
pause
