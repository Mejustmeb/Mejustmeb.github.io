@echo off
python "%~dp0freewillgameb8f6.py" %*
pause
