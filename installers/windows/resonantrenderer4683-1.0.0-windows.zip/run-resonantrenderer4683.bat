@echo off
python "%~dp0resonantrenderer4683.py" %*
pause
