@echo off
python "%~dp0livingmusicenginee0d.py" %*
pause
