@echo off
python "%~dp0guessthenumberearnpoints.py" %*
pause
