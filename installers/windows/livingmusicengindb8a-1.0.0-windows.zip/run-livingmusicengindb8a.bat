@echo off
python "%~dp0livingmusicengindb8a.py" %*
pause
