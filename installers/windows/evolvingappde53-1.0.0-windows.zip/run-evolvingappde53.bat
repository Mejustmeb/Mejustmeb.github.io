@echo off
python "%~dp0evolvingappde53.py" %*
pause
