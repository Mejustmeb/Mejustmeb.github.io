@echo off
python "%~dp0tasktally.py" %*
pause
