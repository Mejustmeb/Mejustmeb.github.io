@echo off
python "%~dp0consequencelabe756.py" %*
pause
