@echo off
python "%~dp0evolvingapp4cd9.py" %*
pause
