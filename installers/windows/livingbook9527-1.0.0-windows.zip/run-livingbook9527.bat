@echo off
python "%~dp0livingbook9527.py" %*
pause
