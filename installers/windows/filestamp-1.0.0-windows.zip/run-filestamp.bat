@echo off
python "%~dp0filestamp.py" %*
pause
