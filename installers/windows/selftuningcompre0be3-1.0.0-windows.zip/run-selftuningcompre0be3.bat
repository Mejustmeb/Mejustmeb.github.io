@echo off
python "%~dp0selftuningcompre0be3.py" %*
pause
