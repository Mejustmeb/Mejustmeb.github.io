@echo off
python "%~dp0freewillgame895e.py" %*
pause
