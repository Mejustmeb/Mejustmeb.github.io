@echo off
python "%~dp0consequencelabb52a.py" %*
pause
