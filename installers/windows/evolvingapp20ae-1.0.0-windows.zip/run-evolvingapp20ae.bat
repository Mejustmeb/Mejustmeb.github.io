@echo off
python "%~dp0evolvingapp20ae.py" %*
pause
