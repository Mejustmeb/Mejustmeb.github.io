@echo off
python "%~dp0resonantrenderer0213.py" %*
pause
