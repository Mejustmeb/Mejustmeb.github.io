@echo off
python "%~dp0livingmusicengind925.py" %*
pause
