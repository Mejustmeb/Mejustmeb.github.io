@echo off
python "%~dp0evolvingapp3f4b.py" %*
pause
