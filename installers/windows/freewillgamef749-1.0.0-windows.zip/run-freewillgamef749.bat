@echo off
python "%~dp0freewillgamef749.py" %*
pause
