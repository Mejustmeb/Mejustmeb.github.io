@echo off
python "%~dp0freewillgameb98d.py" %*
pause
