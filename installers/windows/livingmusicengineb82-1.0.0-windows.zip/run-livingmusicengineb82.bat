@echo off
python "%~dp0livingmusicengineb82.py" %*
pause
