@echo off
python "%~dp0resonantrendererfdc3.py" %*
pause
