@echo off
python "%~dp0evolvingapp8510.py" %*
pause
