@echo off
python "%~dp0selftuningcomprefc5b.py" %*
pause
