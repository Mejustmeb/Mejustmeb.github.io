@echo off
python "%~dp0livingbook7e46.py" %*
pause
