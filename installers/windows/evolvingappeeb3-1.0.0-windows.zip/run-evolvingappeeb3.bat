@echo off
python "%~dp0evolvingappeeb3.py" %*
pause
