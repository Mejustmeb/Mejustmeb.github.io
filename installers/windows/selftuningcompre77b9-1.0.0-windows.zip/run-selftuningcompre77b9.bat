@echo off
python "%~dp0selftuningcompre77b9.py" %*
pause
