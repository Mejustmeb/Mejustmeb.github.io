@echo off
python "%~dp0livingmusicengin5b0a.py" %*
pause
