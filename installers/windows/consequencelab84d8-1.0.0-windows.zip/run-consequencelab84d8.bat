@echo off
python "%~dp0consequencelab84d8.py" %*
pause
