@echo off
python "%~dp0freewillgame5903.py" %*
pause
