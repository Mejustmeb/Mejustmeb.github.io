@echo off
python "%~dp0resonantlanguagebb47.py" %*
pause
