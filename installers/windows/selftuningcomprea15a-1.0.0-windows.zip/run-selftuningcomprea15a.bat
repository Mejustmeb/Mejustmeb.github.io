@echo off
python "%~dp0selftuningcomprea15a.py" %*
pause
