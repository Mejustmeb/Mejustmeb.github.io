@echo off
python "%~dp0selftuningcompre46b5.py" %*
pause
