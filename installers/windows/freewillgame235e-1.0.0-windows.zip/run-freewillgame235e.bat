@echo off
python "%~dp0freewillgame235e.py" %*
pause
