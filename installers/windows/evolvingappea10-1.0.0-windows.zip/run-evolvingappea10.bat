@echo off
python "%~dp0evolvingappea10.py" %*
pause
