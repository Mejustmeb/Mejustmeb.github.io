@echo off
python "%~dp0selftuningcomprecf19.py" %*
pause
