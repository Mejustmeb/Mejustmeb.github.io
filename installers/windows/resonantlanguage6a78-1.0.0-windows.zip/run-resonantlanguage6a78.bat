@echo off
python "%~dp0resonantlanguage6a78.py" %*
pause
