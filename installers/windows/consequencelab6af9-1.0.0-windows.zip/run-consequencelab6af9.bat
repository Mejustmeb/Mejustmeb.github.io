@echo off
python "%~dp0consequencelab6af9.py" %*
pause
