@echo off
python "%~dp0livingbook47f2.py" %*
pause
