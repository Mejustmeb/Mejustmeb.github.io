@echo off
python "%~dp0freewillgame5055.py" %*
pause
