@echo off
python "%~dp0selftuningcomprefa36.py" %*
pause
