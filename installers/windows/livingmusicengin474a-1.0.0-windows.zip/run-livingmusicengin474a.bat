@echo off
python "%~dp0livingmusicengin474a.py" %*
pause
