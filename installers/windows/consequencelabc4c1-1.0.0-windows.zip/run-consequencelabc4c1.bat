@echo off
python "%~dp0consequencelabc4c1.py" %*
pause
