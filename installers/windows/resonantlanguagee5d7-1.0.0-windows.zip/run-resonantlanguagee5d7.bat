@echo off
python "%~dp0resonantlanguagee5d7.py" %*
pause
