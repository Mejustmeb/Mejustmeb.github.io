@echo off
python "%~dp0selftuningcompreb2cf.py" %*
pause
