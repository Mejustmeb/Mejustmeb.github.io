@echo off
python "%~dp0evolvingapp6e13.py" %*
pause
