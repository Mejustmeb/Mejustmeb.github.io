@echo off
python "%~dp0selftuningcompre40ff.py" %*
pause
