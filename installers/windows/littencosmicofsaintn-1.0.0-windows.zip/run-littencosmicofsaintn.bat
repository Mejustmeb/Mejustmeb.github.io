@echo off
python "%~dp0littencosmicofsaintn.py" %*
pause
