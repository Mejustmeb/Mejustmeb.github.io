@echo off
python "%~dp0freewillgamed3b4.py" %*
pause
