@echo off
python "%~dp0livingmusicengin7974.py" %*
pause
