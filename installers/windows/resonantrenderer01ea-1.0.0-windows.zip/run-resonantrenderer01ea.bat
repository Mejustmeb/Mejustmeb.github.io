@echo off
python "%~dp0resonantrenderer01ea.py" %*
pause
