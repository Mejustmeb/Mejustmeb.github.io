@echo off
python "%~dp0resonantlanguage5cfc.py" %*
pause
