@echo off
python "%~dp0selftuningcompre05e5.py" %*
pause
