@echo off
python "%~dp0selftuningcompre6e77.py" %*
pause
