@echo off
python "%~dp0livingmusicengin7092.py" %*
pause
