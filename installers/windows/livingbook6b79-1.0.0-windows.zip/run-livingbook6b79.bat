@echo off
python "%~dp0livingbook6b79.py" %*
pause
