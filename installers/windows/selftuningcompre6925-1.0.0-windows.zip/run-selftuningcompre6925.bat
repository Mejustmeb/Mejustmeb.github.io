@echo off
python "%~dp0selftuningcompre6925.py" %*
pause
