@echo off
python "%~dp0livingbook09c6.py" %*
pause
