@echo off
python "%~dp0guessthenumberbetpoi.py" %*
pause
