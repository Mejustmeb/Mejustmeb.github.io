@echo off
python "%~dp0freewillgameefa8.py" %*
pause
