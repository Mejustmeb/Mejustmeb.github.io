@echo off
python "%~dp0timer.py" %*
pause
