@echo off
python "%~dp0livingbook0fed.py" %*
pause
