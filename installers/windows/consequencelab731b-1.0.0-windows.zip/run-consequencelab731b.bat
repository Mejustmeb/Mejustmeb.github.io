@echo off
python "%~dp0consequencelab731b.py" %*
pause
