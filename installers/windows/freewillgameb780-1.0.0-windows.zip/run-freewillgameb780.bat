@echo off
python "%~dp0freewillgameb780.py" %*
pause
