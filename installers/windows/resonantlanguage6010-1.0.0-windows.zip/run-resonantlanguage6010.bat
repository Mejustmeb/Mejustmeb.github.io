@echo off
python "%~dp0resonantlanguage6010.py" %*
pause
