@echo off
python "%~dp0livingmusicengin081e.py" %*
pause
