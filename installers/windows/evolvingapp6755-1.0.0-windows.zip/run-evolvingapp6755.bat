@echo off
python "%~dp0evolvingapp6755.py" %*
pause
