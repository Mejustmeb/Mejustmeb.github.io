@echo off
python "%~dp0evolvingapp9b97.py" %*
pause
