@echo off
python "%~dp0resonantlanguage2222.py" %*
pause
