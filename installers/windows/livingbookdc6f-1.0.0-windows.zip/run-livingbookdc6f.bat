@echo off
python "%~dp0livingbookdc6f.py" %*
pause
