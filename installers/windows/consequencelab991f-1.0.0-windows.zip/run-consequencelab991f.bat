@echo off
python "%~dp0consequencelab991f.py" %*
pause
