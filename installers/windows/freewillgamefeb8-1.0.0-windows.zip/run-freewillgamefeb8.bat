@echo off
python "%~dp0freewillgamefeb8.py" %*
pause
