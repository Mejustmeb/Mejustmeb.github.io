@echo off
python "%~dp0resonantlanguage9273.py" %*
pause
