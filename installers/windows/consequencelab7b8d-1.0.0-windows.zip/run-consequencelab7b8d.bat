@echo off
python "%~dp0consequencelab7b8d.py" %*
pause
