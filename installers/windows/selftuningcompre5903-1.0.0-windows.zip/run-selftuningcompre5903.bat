@echo off
python "%~dp0selftuningcompre5903.py" %*
pause
