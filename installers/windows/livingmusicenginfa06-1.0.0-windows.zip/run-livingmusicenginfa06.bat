@echo off
python "%~dp0livingmusicenginfa06.py" %*
pause
