@echo off
python "%~dp0freewillgame1970.py" %*
pause
