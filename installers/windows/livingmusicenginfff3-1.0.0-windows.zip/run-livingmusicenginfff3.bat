@echo off
python "%~dp0livingmusicenginfff3.py" %*
pause
