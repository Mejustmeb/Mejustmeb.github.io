@echo off
python "%~dp0freewillgamea4e4.py" %*
pause
