@echo off
python "%~dp0selftuningcompre1ecd.py" %*
pause
