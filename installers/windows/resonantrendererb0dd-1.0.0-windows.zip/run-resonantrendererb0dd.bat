@echo off
python "%~dp0resonantrendererb0dd.py" %*
pause
