@echo off
python "%~dp0livingbook7ebe.py" %*
pause
