@echo off
python "%~dp0consequencelabad76.py" %*
pause
