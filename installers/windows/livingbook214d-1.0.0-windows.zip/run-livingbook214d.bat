@echo off
python "%~dp0livingbook214d.py" %*
pause
