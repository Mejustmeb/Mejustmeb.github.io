@echo off
python "%~dp0evolvingapp1970.py" %*
pause
