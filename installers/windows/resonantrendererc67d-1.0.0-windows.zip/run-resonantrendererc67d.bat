@echo off
python "%~dp0resonantrendererc67d.py" %*
pause
