@echo off
python "%~dp0consequencelab4f8a.py" %*
pause
