@echo off
python "%~dp0evolvingapp5978.py" %*
pause
