@echo off
python "%~dp0freewillgame0234.py" %*
pause
