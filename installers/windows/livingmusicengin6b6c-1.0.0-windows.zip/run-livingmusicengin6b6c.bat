@echo off
python "%~dp0livingmusicengin6b6c.py" %*
pause
