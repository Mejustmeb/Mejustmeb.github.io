@echo off
python "%~dp0livingmusicengin6bc7.py" %*
pause
