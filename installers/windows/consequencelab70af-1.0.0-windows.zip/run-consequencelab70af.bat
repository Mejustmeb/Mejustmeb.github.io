@echo off
python "%~dp0consequencelab70af.py" %*
pause
