@echo off
python "%~dp0livingmusicenginf80c.py" %*
pause
