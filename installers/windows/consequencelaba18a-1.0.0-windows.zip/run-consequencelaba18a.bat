@echo off
python "%~dp0consequencelaba18a.py" %*
pause
