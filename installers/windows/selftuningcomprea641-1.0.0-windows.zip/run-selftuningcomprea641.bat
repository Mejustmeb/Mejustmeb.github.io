@echo off
python "%~dp0selftuningcomprea641.py" %*
pause
