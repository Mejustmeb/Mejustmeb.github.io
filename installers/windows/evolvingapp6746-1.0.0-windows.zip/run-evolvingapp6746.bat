@echo off
python "%~dp0evolvingapp6746.py" %*
pause
