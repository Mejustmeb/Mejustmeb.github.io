@echo off
python "%~dp0resonantlanguageeddc.py" %*
pause
