@echo off
python "%~dp0livingmusicenginb68c.py" %*
pause
