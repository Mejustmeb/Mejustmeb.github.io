@echo off
python "%~dp0resonantrenderer32a4.py" %*
pause
