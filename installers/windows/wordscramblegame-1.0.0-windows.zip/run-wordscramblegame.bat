@echo off
python "%~dp0wordscramblegame.py" %*
pause
