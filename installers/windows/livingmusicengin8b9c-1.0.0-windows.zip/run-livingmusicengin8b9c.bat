@echo off
python "%~dp0livingmusicengin8b9c.py" %*
pause
