@echo off
python "%~dp0resonantrendererabcd.py" %*
pause
