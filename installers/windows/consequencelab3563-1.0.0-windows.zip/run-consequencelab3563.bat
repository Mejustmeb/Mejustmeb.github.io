@echo off
python "%~dp0consequencelab3563.py" %*
pause
