@echo off
python "%~dp0resonantlanguage33d6.py" %*
pause
