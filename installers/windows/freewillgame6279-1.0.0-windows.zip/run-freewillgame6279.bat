@echo off
python "%~dp0freewillgame6279.py" %*
pause
