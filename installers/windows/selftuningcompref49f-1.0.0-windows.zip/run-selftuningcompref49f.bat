@echo off
python "%~dp0selftuningcompref49f.py" %*
pause
