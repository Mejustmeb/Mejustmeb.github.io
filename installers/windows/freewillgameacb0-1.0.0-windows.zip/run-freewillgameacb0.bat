@echo off
python "%~dp0freewillgameacb0.py" %*
pause
