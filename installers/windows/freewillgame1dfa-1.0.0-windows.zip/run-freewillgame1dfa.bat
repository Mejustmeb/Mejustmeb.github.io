@echo off
python "%~dp0freewillgame1dfa.py" %*
pause
