@echo off
python "%~dp0livingbook117e.py" %*
pause
