@echo off
python "%~dp0freewillgame790f.py" %*
pause
