@echo off
python "%~dp0resonantlanguage808d.py" %*
pause
