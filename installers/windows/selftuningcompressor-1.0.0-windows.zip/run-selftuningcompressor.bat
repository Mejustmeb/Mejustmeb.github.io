@echo off
python "%~dp0selftuningcompressor.py" %*
pause
