@echo off
python "%~dp0evolvingapp790e.py" %*
pause
