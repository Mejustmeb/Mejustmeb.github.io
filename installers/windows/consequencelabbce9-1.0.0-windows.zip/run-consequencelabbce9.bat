@echo off
python "%~dp0consequencelabbce9.py" %*
pause
