@echo off
python "%~dp0evolvingappade8.py" %*
pause
