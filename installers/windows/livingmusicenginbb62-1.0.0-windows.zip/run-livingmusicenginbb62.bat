@echo off
python "%~dp0livingmusicenginbb62.py" %*
pause
