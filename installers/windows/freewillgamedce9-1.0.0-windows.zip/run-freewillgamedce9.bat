@echo off
python "%~dp0freewillgamedce9.py" %*
pause
