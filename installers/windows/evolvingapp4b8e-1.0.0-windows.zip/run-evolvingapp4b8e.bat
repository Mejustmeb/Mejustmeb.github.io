@echo off
python "%~dp0evolvingapp4b8e.py" %*
pause
