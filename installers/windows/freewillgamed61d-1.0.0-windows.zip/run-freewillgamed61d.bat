@echo off
python "%~dp0freewillgamed61d.py" %*
pause
