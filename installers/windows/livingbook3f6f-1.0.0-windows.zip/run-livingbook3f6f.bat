@echo off
python "%~dp0livingbook3f6f.py" %*
pause
