@echo off
python "%~dp0freewillgame9809.py" %*
pause
