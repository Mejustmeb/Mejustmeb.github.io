@echo off
python "%~dp0selftuningcompre6137.py" %*
pause
