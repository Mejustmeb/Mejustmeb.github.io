@echo off
python "%~dp0livingbookb904.py" %*
pause
