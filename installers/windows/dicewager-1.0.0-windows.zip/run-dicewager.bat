@echo off
python "%~dp0dicewager.py" %*
pause
