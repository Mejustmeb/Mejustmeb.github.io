@echo off
python "%~dp0consequencelab465e.py" %*
pause
