@echo off
python "%~dp0livingbook2811.py" %*
pause
