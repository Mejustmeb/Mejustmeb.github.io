@echo off
python "%~dp0tictactoegui.py" %*
pause
