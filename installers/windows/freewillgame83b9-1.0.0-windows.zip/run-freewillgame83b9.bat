@echo off
python "%~dp0freewillgame83b9.py" %*
pause
