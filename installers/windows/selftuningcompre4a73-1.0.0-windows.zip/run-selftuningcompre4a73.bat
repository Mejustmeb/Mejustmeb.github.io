@echo off
python "%~dp0selftuningcompre4a73.py" %*
pause
