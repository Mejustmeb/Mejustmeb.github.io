@echo off
python "%~dp0livingbook4a39.py" %*
pause
