@echo off
python "%~dp0selftuningcomprefbe9.py" %*
pause
