@echo off
python "%~dp0resonantrenderer3651.py" %*
pause
