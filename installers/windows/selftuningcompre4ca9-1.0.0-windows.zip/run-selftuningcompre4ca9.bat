@echo off
python "%~dp0selftuningcompre4ca9.py" %*
pause
