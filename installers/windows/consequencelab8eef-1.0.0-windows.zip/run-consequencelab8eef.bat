@echo off
python "%~dp0consequencelab8eef.py" %*
pause
