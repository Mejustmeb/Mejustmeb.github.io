@echo off
python "%~dp0livingbook3cb1.py" %*
pause
