@echo off
python "%~dp0resonantrenderere7a8.py" %*
pause
