@echo off
python "%~dp0livingmusicengin251b.py" %*
pause
