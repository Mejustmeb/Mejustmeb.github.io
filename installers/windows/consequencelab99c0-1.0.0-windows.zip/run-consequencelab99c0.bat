@echo off
python "%~dp0consequencelab99c0.py" %*
pause
