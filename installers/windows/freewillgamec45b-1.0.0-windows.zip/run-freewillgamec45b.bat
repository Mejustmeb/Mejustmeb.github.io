@echo off
python "%~dp0freewillgamec45b.py" %*
pause
