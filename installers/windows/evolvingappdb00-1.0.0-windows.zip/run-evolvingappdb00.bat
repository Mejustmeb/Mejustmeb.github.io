@echo off
python "%~dp0evolvingappdb00.py" %*
pause
