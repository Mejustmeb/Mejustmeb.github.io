@echo off
python "%~dp0livingbook4a75.py" %*
pause
