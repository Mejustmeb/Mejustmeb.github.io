@echo off
python "%~dp0selftuningcompre2630.py" %*
pause
