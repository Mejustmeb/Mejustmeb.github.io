@echo off
python "%~dp0livingmusicengind8ee.py" %*
pause
