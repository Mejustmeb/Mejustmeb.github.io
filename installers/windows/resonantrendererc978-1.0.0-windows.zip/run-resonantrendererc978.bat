@echo off
python "%~dp0resonantrendererc978.py" %*
pause
