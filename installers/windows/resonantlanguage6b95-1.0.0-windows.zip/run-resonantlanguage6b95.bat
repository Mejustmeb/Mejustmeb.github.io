@echo off
python "%~dp0resonantlanguage6b95.py" %*
pause
