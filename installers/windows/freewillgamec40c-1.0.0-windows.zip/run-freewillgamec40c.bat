@echo off
python "%~dp0freewillgamec40c.py" %*
pause
