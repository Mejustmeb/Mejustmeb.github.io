@echo off
python "%~dp0evolvingapp1d6a.py" %*
pause
