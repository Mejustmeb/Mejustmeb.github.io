@echo off
python "%~dp0livingbook0122.py" %*
pause
