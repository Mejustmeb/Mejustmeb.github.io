@echo off
python "%~dp0freewillgame195c.py" %*
pause
