@echo off
python "%~dp0resonantlanguage7ffc.py" %*
pause
