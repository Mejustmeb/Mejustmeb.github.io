@echo off
python "%~dp0selftuningcomprec18a.py" %*
pause
