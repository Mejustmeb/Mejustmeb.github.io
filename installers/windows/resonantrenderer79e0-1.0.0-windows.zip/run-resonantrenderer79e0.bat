@echo off
python "%~dp0resonantrenderer79e0.py" %*
pause
