@echo off
python "%~dp0resonantlanguage8424.py" %*
pause
