@echo off
python "%~dp0freewillgamec54c.py" %*
pause
