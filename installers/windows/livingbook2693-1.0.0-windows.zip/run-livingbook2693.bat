@echo off
python "%~dp0livingbook2693.py" %*
pause
