@echo off
python "%~dp0livingmusicengin5717.py" %*
pause
