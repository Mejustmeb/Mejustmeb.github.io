@echo off
python "%~dp0selftuningcomprea197.py" %*
pause
