@echo off
python "%~dp0freewillgame2590.py" %*
pause
