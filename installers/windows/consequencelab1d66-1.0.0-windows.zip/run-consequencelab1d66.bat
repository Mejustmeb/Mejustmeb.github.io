@echo off
python "%~dp0consequencelab1d66.py" %*
pause
