@echo off
python "%~dp0guessnumber.py" %*
pause
