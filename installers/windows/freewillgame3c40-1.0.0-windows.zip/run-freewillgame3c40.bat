@echo off
python "%~dp0freewillgame3c40.py" %*
pause
