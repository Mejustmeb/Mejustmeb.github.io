@echo off
python "%~dp0freewillgame59be.py" %*
pause
