@echo off
python "%~dp0dice.py" %*
pause
