@echo off
python "%~dp0resonantrenderer5414.py" %*
pause
