@echo off
python "%~dp0freewillgame38d2.py" %*
pause
