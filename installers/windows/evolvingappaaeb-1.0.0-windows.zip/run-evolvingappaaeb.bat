@echo off
python "%~dp0evolvingappaaeb.py" %*
pause
