@echo off
python "%~dp0freewillgameaa03.py" %*
pause
