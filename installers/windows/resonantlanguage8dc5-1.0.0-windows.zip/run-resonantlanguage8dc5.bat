@echo off
python "%~dp0resonantlanguage8dc5.py" %*
pause
