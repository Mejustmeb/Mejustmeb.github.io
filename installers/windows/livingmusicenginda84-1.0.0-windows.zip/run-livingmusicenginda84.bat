@echo off
python "%~dp0livingmusicenginda84.py" %*
pause
