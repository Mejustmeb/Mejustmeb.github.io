@echo off
python "%~dp0livingbook5727.py" %*
pause
