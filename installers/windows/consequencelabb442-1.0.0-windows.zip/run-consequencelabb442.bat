@echo off
python "%~dp0consequencelabb442.py" %*
pause
