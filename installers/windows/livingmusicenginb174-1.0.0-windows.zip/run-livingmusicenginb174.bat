@echo off
python "%~dp0livingmusicenginb174.py" %*
pause
