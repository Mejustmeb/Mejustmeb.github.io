@echo off
python "%~dp0evolvingapp811b.py" %*
pause
