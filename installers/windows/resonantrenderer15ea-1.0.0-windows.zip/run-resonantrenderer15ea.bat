@echo off
python "%~dp0resonantrenderer15ea.py" %*
pause
