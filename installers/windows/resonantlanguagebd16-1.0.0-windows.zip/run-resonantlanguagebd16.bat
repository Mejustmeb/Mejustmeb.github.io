@echo off
python "%~dp0resonantlanguagebd16.py" %*
pause
