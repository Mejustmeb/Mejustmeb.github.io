@echo off
python "%~dp0resonantrenderer0e5e.py" %*
pause
