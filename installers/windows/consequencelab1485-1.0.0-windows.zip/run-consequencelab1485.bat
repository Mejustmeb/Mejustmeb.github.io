@echo off
python "%~dp0consequencelab1485.py" %*
pause
