@echo off
python "%~dp0selftuningcompre9593.py" %*
pause
