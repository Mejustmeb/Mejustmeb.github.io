@echo off
python "%~dp0resonantlanguage54c3.py" %*
pause
