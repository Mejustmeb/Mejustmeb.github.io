@echo off
python "%~dp0consequencelab5c8e.py" %*
pause
