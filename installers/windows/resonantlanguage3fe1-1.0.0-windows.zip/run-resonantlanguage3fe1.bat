@echo off
python "%~dp0resonantlanguage3fe1.py" %*
pause
