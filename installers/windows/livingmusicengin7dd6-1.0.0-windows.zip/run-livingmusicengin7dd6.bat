@echo off
python "%~dp0livingmusicengin7dd6.py" %*
pause
