@echo off
python "%~dp0selftuningcompref1ee.py" %*
pause
