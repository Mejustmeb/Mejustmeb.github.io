@echo off
python "%~dp0selftuningcompredfcb.py" %*
pause
