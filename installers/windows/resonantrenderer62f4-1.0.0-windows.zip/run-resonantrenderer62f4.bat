@echo off
python "%~dp0resonantrenderer62f4.py" %*
pause
