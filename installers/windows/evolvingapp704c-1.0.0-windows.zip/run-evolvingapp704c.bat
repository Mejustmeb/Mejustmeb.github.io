@echo off
python "%~dp0evolvingapp704c.py" %*
pause
