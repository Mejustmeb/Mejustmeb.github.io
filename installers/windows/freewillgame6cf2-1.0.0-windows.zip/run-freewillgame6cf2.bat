@echo off
python "%~dp0freewillgame6cf2.py" %*
pause
