@echo off
python "%~dp0resonantrenderer1330.py" %*
pause
