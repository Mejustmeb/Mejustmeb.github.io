@echo off
python "%~dp0consequencelabd85c.py" %*
pause
