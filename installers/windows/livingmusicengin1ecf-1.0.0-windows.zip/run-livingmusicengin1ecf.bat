@echo off
python "%~dp0livingmusicengin1ecf.py" %*
pause
