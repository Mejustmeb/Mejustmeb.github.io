@echo off
python "%~dp0livingmusicengin115b.py" %*
pause
