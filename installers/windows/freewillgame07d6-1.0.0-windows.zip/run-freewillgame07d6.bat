@echo off
python "%~dp0freewillgame07d6.py" %*
pause
