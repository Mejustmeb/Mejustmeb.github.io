@echo off
python "%~dp0consequencelaba814.py" %*
pause
