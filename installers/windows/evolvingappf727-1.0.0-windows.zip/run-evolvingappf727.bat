@echo off
python "%~dp0evolvingappf727.py" %*
pause
