@echo off
python "%~dp0evolvingapp8389.py" %*
pause
