@echo off
python "%~dp0selftuningcompre36d6.py" %*
pause
