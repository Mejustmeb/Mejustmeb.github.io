@echo off
python "%~dp0resonantrendererb8a1.py" %*
pause
