@echo off
python "%~dp0consequencelab6497.py" %*
pause
