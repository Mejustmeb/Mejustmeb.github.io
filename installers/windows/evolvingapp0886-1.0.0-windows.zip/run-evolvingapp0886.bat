@echo off
python "%~dp0evolvingapp0886.py" %*
pause
