#!/usr/bin/env python3
"""Free-Will Game 987C - a adventure game by Echo."""
import random

ITEMS = ['bluetooth', 'lighting', 'cornflowerblue', 'Manganese', 'rabbit']

def play(seed=None):
    """Run one hunt. Returns True if the goal is found."""
    rng = random.Random(seed)
    goal = rng.choice(ITEMS)
    print("=== Free-Will Game 987C ===")
    print("You are Rabbit, exploring Carmen de Areco.")
    print("Theme: A game engine that shares its reasoning with the person usin")
    print("Goal: find the " + goal + ".")
    bag = []
    for i in range(3):
        found = rng.choice(ITEMS)
        bag.append(found)
        print("  spot " + str(i + 1) + ": " + found)
    if goal in bag:
        print("VICTORY - you found the " + goal + "!")
        return True
    print("The " + goal + " eluded you.")
    return False

if __name__ == "__main__":
    play()
