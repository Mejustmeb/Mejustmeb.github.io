@echo off
python "%~dp0freewillgame987c.py" %*
pause
