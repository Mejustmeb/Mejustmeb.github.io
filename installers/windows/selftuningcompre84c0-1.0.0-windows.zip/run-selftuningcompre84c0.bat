@echo off
python "%~dp0selftuningcompre84c0.py" %*
pause
