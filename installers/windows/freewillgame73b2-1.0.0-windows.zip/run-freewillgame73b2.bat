@echo off
python "%~dp0freewillgame73b2.py" %*
pause
