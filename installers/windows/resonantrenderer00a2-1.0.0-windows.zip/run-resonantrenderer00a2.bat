@echo off
python "%~dp0resonantrenderer00a2.py" %*
pause
