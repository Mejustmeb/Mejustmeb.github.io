@echo off
python "%~dp0selftuningcompre1ba0.py" %*
pause
