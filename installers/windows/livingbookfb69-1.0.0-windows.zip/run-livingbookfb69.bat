@echo off
python "%~dp0livingbookfb69.py" %*
pause
