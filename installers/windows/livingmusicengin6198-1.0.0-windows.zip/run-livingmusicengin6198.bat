@echo off
python "%~dp0livingmusicengin6198.py" %*
pause
