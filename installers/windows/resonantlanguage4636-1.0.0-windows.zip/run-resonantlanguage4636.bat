@echo off
python "%~dp0resonantlanguage4636.py" %*
pause
