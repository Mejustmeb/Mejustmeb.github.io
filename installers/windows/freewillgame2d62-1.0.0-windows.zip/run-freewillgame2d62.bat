@echo off
python "%~dp0freewillgame2d62.py" %*
pause
