@echo off
python "%~dp0livingmusicengine174.py" %*
pause
