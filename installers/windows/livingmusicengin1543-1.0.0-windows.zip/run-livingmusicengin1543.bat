@echo off
python "%~dp0livingmusicengin1543.py" %*
pause
