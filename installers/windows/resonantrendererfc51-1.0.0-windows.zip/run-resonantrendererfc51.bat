@echo off
python "%~dp0resonantrendererfc51.py" %*
pause
