@echo off
python "%~dp0freewillgame6da6.py" %*
pause
