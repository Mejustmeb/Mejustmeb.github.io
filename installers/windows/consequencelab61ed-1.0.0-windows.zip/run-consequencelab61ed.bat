@echo off
python "%~dp0consequencelab61ed.py" %*
pause
