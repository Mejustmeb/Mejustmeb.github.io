@echo off
python "%~dp0mergefiles.py" %*
pause
