@echo off
python "%~dp0evolvingapp7f5a.py" %*
pause
