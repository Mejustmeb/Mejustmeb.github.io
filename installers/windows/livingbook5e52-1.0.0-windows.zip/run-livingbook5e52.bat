@echo off
python "%~dp0livingbook5e52.py" %*
pause
