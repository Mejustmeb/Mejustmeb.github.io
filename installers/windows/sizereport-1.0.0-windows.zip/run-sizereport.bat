@echo off
python "%~dp0sizereport.py" %*
pause
