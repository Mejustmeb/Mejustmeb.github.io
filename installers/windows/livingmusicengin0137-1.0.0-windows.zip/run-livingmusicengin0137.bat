@echo off
python "%~dp0livingmusicengin0137.py" %*
pause
