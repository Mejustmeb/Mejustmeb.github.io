@echo off
python "%~dp0livingmusicengineba7.py" %*
pause
