@echo off
python "%~dp0livingmusicengin85bb.py" %*
pause
