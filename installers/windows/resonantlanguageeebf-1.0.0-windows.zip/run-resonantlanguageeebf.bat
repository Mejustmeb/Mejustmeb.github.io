@echo off
python "%~dp0resonantlanguageeebf.py" %*
pause
