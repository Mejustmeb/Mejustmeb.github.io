@echo off
python "%~dp0armaldofumingofmanik.py" %*
pause
