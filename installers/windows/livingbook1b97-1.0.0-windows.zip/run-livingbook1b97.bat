@echo off
python "%~dp0livingbook1b97.py" %*
pause
