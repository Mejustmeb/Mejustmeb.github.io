@echo off
python "%~dp0evolvingappf6ef.py" %*
pause
