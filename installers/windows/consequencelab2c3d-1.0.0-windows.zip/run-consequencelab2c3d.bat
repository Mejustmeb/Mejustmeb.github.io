@echo off
python "%~dp0consequencelab2c3d.py" %*
pause
