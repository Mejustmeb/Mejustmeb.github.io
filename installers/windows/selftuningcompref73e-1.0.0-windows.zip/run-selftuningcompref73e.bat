@echo off
python "%~dp0selftuningcompref73e.py" %*
pause
