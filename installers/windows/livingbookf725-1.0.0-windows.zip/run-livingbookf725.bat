@echo off
python "%~dp0livingbookf725.py" %*
pause
