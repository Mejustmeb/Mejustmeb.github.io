@echo off
python "%~dp0selftuningcompre8d16.py" %*
pause
