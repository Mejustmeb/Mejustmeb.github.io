@echo off
python "%~dp0timeattack.py" %*
pause
