@echo off
python "%~dp0resonantrenderere1af.py" %*
pause
