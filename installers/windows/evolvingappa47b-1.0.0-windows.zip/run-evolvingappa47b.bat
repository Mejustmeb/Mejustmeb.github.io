@echo off
python "%~dp0evolvingappa47b.py" %*
pause
