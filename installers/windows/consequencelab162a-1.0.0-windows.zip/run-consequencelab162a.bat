@echo off
python "%~dp0consequencelab162a.py" %*
pause
