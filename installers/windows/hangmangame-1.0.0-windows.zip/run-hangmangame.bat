@echo off
python "%~dp0hangmangame.py" %*
pause
