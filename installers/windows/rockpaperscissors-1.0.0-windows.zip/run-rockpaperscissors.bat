@echo off
python "%~dp0rockpaperscissors.py" %*
pause
