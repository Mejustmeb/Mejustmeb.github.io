@echo off
python "%~dp0resonantrendererc11f.py" %*
pause
