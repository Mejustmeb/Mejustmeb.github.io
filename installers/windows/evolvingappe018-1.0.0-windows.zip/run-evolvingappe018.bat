@echo off
python "%~dp0evolvingappe018.py" %*
pause
