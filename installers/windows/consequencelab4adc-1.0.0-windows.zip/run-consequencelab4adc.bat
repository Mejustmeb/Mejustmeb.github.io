@echo off
python "%~dp0consequencelab4adc.py" %*
pause
