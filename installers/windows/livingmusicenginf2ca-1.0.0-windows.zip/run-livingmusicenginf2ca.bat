@echo off
python "%~dp0livingmusicenginf2ca.py" %*
pause
