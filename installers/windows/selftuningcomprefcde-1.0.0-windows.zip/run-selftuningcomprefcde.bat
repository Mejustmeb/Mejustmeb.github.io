@echo off
python "%~dp0selftuningcomprefcde.py" %*
pause
