@echo off
python "%~dp0livingbook9236.py" %*
pause
