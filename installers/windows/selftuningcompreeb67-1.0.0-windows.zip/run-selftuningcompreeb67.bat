@echo off
python "%~dp0selftuningcompreeb67.py" %*
pause
