@echo off
python "%~dp0evolvingappa159.py" %*
pause
