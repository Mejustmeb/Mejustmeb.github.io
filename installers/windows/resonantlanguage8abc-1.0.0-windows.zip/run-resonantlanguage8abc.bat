@echo off
python "%~dp0resonantlanguage8abc.py" %*
pause
