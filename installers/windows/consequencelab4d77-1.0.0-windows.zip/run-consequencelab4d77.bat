@echo off
python "%~dp0consequencelab4d77.py" %*
pause
