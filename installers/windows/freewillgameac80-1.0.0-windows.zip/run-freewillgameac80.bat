@echo off
python "%~dp0freewillgameac80.py" %*
pause
