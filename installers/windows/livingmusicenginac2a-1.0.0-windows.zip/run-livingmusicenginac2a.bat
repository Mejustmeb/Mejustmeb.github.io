@echo off
python "%~dp0livingmusicenginac2a.py" %*
pause
