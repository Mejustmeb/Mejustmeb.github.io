@echo off
python "%~dp0evolvingapp1789.py" %*
pause
