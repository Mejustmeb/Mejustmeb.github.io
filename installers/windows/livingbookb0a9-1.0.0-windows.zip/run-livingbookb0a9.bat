@echo off
python "%~dp0livingbookb0a9.py" %*
pause
