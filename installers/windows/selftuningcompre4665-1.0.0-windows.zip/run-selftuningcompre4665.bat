@echo off
python "%~dp0selftuningcompre4665.py" %*
pause
