@echo off
python "%~dp0selftuningcompreca23.py" %*
pause
