@echo off
python "%~dp0resonantrenderere588.py" %*
pause
