@echo off
python "%~dp0freewillgame7909.py" %*
pause
