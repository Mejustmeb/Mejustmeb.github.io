@echo off
python "%~dp0consequencelabb4b8.py" %*
pause
