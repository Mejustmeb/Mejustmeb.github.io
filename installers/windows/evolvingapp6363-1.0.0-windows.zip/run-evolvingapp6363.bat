@echo off
python "%~dp0evolvingapp6363.py" %*
pause
