@echo off
python "%~dp0evolvingapp8db7.py" %*
pause
