@echo off
python "%~dp0livingmusicenginb760.py" %*
pause
