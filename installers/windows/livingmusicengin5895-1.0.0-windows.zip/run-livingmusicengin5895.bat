@echo off
python "%~dp0livingmusicengin5895.py" %*
pause
