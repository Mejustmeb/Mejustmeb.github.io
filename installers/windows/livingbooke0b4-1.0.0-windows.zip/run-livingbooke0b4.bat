@echo off
python "%~dp0livingbooke0b4.py" %*
pause
