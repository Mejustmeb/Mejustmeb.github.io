@echo off
python "%~dp0resonantlanguageec08.py" %*
pause
