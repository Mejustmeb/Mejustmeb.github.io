@echo off
python "%~dp0freewillgameeac5.py" %*
pause
