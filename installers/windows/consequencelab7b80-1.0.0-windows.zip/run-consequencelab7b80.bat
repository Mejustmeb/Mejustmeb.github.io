@echo off
python "%~dp0consequencelab7b80.py" %*
pause
