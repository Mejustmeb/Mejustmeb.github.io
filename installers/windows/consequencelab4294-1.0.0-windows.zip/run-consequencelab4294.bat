@echo off
python "%~dp0consequencelab4294.py" %*
pause
