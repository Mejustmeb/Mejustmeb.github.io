@echo off
python "%~dp0livingmusicengin5795.py" %*
pause
