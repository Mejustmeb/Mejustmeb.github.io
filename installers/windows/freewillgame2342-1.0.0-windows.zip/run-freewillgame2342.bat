@echo off
python "%~dp0freewillgame2342.py" %*
pause
