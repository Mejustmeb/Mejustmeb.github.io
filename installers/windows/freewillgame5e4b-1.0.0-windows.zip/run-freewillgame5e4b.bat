@echo off
python "%~dp0freewillgame5e4b.py" %*
pause
