@echo off
python "%~dp0consequencelab24ea.py" %*
pause
