@echo off
python "%~dp0selftuningcompre2885.py" %*
pause
