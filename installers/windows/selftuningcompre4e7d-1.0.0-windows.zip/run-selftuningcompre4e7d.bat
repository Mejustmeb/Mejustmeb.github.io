@echo off
python "%~dp0selftuningcompre4e7d.py" %*
pause
