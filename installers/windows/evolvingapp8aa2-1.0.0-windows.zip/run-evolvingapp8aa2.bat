@echo off
python "%~dp0evolvingapp8aa2.py" %*
pause
