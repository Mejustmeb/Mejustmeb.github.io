@echo off
python "%~dp0evolvingappa288.py" %*
pause
