@echo off
python "%~dp0livingbook64c8.py" %*
pause
