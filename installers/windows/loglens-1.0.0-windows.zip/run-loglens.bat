@echo off
python "%~dp0loglens.py" %*
pause
