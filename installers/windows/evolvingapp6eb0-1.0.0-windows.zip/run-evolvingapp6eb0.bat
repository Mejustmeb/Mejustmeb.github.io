@echo off
python "%~dp0evolvingapp6eb0.py" %*
pause
