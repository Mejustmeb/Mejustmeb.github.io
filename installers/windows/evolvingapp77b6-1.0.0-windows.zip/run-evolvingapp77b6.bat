@echo off
python "%~dp0evolvingapp77b6.py" %*
pause
