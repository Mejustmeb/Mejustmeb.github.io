@echo off
python "%~dp0resonantrendererd40c.py" %*
pause
