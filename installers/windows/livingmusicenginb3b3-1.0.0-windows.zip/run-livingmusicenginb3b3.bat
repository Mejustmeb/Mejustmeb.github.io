@echo off
python "%~dp0livingmusicenginb3b3.py" %*
pause
