@echo off
python "%~dp0resonantrenderer4cd1.py" %*
pause
