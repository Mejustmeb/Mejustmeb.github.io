@echo off
python "%~dp0resonantrenderer56be.py" %*
pause
