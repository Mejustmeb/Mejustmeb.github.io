@echo off
python "%~dp0livingmusicengind367.py" %*
pause
