@echo off
python "%~dp0freewillgame49d6.py" %*
pause
