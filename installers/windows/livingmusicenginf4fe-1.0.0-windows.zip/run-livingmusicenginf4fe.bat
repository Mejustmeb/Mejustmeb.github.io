@echo off
python "%~dp0livingmusicenginf4fe.py" %*
pause
