@echo off
python "%~dp0resonantrendererc323.py" %*
pause
