@echo off
python "%~dp0resonantrenderere8b8.py" %*
pause
