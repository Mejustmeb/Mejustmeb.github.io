@echo off
python "%~dp0resonantrenderereafc.py" %*
pause
