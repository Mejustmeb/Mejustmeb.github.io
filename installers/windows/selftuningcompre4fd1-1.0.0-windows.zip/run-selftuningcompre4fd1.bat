@echo off
python "%~dp0selftuningcompre4fd1.py" %*
pause
