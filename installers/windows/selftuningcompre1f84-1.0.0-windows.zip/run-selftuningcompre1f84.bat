@echo off
python "%~dp0selftuningcompre1f84.py" %*
pause
