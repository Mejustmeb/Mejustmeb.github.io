@echo off
python "%~dp0livingbook40df.py" %*
pause
