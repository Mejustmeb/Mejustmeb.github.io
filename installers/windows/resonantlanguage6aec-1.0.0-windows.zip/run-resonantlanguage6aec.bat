@echo off
python "%~dp0resonantlanguage6aec.py" %*
pause
