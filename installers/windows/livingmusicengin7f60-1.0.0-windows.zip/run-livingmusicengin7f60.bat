@echo off
python "%~dp0livingmusicengin7f60.py" %*
pause
