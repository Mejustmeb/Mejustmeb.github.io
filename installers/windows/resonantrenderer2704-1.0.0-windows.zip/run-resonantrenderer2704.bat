@echo off
python "%~dp0resonantrenderer2704.py" %*
pause
