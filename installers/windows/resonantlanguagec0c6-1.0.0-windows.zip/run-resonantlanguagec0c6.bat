@echo off
python "%~dp0resonantlanguagec0c6.py" %*
pause
