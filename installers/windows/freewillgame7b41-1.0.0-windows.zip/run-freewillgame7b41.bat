@echo off
python "%~dp0freewillgame7b41.py" %*
pause
