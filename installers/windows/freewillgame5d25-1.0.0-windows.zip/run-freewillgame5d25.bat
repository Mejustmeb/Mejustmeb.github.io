@echo off
python "%~dp0freewillgame5d25.py" %*
pause
