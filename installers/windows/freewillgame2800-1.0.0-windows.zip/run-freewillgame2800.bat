@echo off
python "%~dp0freewillgame2800.py" %*
pause
