@echo off
python "%~dp0resonantlanguageb717.py" %*
pause
