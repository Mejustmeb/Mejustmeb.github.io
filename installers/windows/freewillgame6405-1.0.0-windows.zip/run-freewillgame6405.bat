@echo off
python "%~dp0freewillgame6405.py" %*
pause
