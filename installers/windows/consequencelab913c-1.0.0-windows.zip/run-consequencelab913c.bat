@echo off
python "%~dp0consequencelab913c.py" %*
pause
