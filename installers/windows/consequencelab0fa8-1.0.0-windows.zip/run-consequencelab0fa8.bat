@echo off
python "%~dp0consequencelab0fa8.py" %*
pause
