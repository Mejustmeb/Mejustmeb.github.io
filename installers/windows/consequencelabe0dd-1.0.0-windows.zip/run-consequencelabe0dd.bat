@echo off
python "%~dp0consequencelabe0dd.py" %*
pause
