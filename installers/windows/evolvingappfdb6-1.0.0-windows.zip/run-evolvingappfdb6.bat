@echo off
python "%~dp0evolvingappfdb6.py" %*
pause
