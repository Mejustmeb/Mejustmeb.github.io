@echo off
python "%~dp0resonantrenderer1003.py" %*
pause
