@echo off
python "%~dp0livingbooke399.py" %*
pause
