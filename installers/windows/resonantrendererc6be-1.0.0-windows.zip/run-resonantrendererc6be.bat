@echo off
python "%~dp0resonantrendererc6be.py" %*
pause
