@echo off
python "%~dp0resonantlanguage7c56.py" %*
pause
