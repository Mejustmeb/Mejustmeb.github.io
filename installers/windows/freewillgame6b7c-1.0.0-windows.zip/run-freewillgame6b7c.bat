@echo off
python "%~dp0freewillgame6b7c.py" %*
pause
