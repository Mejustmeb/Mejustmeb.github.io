@echo off
python "%~dp0selftuningcompre01b8.py" %*
pause
