@echo off
python "%~dp0freewillgame56a6.py" %*
pause
