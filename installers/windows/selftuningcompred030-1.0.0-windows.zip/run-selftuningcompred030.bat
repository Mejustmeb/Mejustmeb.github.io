@echo off
python "%~dp0selftuningcompred030.py" %*
pause
