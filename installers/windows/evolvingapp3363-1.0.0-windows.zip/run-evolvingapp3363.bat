@echo off
python "%~dp0evolvingapp3363.py" %*
pause
