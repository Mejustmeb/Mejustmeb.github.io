@echo off
python "%~dp0resonantrenderer476b.py" %*
pause
