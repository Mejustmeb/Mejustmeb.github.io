@echo off
python "%~dp0resonantlanguaged940.py" %*
pause
