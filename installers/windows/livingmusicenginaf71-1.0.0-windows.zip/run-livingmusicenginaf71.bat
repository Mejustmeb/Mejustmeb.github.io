@echo off
python "%~dp0livingmusicenginaf71.py" %*
pause
