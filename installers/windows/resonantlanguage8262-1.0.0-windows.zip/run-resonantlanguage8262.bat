@echo off
python "%~dp0resonantlanguage8262.py" %*
pause
