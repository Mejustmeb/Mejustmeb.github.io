@echo off
python "%~dp0livingmusicengina643.py" %*
pause
