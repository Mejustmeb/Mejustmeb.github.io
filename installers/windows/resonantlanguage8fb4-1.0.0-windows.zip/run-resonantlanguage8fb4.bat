@echo off
python "%~dp0resonantlanguage8fb4.py" %*
pause
