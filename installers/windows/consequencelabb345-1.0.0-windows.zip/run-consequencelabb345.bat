@echo off
python "%~dp0consequencelabb345.py" %*
pause
