@echo off
python "%~dp0selftuningcompre7a85.py" %*
pause
