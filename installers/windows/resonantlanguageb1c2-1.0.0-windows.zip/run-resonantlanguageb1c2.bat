@echo off
python "%~dp0resonantlanguageb1c2.py" %*
pause
