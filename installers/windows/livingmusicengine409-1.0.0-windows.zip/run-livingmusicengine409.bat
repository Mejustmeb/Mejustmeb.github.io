@echo off
python "%~dp0livingmusicengine409.py" %*
pause
