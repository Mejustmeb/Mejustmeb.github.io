@echo off
python "%~dp0livingmusicengin81b4.py" %*
pause
