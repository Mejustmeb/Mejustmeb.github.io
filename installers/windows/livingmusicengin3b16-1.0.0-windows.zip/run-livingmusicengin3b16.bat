@echo off
python "%~dp0livingmusicengin3b16.py" %*
pause
