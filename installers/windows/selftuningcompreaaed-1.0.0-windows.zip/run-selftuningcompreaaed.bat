@echo off
python "%~dp0selftuningcompreaaed.py" %*
pause
