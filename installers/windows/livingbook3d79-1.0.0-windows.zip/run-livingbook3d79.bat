@echo off
python "%~dp0livingbook3d79.py" %*
pause
