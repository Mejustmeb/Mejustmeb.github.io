@echo off
python "%~dp0livingbook6eb2.py" %*
pause
