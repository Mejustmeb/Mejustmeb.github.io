@echo off
python "%~dp0livingbookf1c4.py" %*
pause
