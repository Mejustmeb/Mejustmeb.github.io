@echo off
python "%~dp0consequencelabb911.py" %*
pause
