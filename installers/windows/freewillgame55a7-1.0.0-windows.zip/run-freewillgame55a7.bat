@echo off
python "%~dp0freewillgame55a7.py" %*
pause
