@echo off
python "%~dp0resonantlanguagef2c4.py" %*
pause
