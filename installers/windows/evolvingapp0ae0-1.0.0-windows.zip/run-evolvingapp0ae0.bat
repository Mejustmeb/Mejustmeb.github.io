@echo off
python "%~dp0evolvingapp0ae0.py" %*
pause
