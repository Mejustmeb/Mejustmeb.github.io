@echo off
python "%~dp0livingmusicengind435.py" %*
pause
