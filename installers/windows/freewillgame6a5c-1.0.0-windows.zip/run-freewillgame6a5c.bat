@echo off
python "%~dp0freewillgame6a5c.py" %*
pause
