@echo off
python "%~dp0livingmusicengin5bc7.py" %*
pause
