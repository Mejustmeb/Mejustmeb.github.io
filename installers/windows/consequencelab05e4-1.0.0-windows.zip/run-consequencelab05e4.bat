@echo off
python "%~dp0consequencelab05e4.py" %*
pause
