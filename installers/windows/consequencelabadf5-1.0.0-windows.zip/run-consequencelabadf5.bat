@echo off
python "%~dp0consequencelabadf5.py" %*
pause
