@echo off
python "%~dp0selftuningcompreb808.py" %*
pause
