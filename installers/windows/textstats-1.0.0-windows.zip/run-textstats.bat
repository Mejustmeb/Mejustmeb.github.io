@echo off
python "%~dp0textstats.py" %*
pause
