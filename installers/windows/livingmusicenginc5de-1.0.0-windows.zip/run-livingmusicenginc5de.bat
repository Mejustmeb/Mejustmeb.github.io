@echo off
python "%~dp0livingmusicenginc5de.py" %*
pause
