@echo off
python "%~dp0evolvingapp9ee2.py" %*
pause
