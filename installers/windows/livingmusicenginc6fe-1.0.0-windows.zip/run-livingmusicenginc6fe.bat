@echo off
python "%~dp0livingmusicenginc6fe.py" %*
pause
