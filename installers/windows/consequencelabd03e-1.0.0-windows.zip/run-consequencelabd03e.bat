@echo off
python "%~dp0consequencelabd03e.py" %*
pause
