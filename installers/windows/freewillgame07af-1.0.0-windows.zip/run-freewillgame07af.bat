@echo off
python "%~dp0freewillgame07af.py" %*
pause
