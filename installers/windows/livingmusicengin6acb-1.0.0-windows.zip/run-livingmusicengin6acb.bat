@echo off
python "%~dp0livingmusicengin6acb.py" %*
pause
