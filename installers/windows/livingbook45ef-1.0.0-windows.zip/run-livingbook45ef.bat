@echo off
python "%~dp0livingbook45ef.py" %*
pause
