@echo off
python "%~dp0consequencelab8eda.py" %*
pause
