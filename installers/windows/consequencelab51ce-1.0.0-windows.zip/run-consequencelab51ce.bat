@echo off
python "%~dp0consequencelab51ce.py" %*
pause
