@echo off
python "%~dp0freewillgame635a.py" %*
pause
