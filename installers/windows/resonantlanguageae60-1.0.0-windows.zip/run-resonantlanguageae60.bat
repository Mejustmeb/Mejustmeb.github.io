@echo off
python "%~dp0resonantlanguageae60.py" %*
pause
