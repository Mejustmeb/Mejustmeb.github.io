@echo off
python "%~dp0resonantlanguage702b.py" %*
pause
