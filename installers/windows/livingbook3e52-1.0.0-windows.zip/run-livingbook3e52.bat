@echo off
python "%~dp0livingbook3e52.py" %*
pause
