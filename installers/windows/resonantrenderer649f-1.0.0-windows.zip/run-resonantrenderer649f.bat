@echo off
python "%~dp0resonantrenderer649f.py" %*
pause
