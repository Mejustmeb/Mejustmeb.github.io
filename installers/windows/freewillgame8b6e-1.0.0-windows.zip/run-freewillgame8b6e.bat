@echo off
python "%~dp0freewillgame8b6e.py" %*
pause
