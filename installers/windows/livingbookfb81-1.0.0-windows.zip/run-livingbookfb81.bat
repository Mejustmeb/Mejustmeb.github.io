@echo off
python "%~dp0livingbookfb81.py" %*
pause
