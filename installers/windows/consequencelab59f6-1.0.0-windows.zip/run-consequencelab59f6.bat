@echo off
python "%~dp0consequencelab59f6.py" %*
pause
