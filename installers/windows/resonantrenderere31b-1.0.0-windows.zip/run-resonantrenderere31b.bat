@echo off
python "%~dp0resonantrenderere31b.py" %*
pause
