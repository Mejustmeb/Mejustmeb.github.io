@echo off
python "%~dp0evolvingapp9692.py" %*
pause
