@echo off
python "%~dp0selftuningcompre3456.py" %*
pause
