@echo off
python "%~dp0consequencelabafe9.py" %*
pause
