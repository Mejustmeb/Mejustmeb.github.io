@echo off
python "%~dp0livingmusicengindf94.py" %*
pause
