@echo off
python "%~dp0resonantlanguage88bc.py" %*
pause
