@echo off
python "%~dp0resonantlanguagee19a.py" %*
pause
