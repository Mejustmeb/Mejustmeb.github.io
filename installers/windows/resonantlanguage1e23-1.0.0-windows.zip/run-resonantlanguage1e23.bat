@echo off
python "%~dp0resonantlanguage1e23.py" %*
pause
