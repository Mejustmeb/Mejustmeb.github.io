@echo off
python "%~dp0freewillgamed0c3.py" %*
pause
