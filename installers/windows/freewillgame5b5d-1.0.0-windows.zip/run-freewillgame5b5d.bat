@echo off
python "%~dp0freewillgame5b5d.py" %*
pause
