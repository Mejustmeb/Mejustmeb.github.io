@echo off
python "%~dp0resonantrenderer6d08.py" %*
pause
