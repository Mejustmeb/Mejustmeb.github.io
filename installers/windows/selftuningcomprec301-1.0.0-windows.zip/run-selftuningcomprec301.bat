@echo off
python "%~dp0selftuningcomprec301.py" %*
pause
