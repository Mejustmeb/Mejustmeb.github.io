@echo off
python "%~dp0livingmusicengin4995.py" %*
pause
