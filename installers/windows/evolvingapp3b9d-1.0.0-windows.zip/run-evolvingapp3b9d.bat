@echo off
python "%~dp0evolvingapp3b9d.py" %*
pause
