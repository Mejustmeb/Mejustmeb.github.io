@echo off
python "%~dp0selftuningcompre8da7.py" %*
pause
