@echo off
python "%~dp0freewillgamed22d.py" %*
pause
