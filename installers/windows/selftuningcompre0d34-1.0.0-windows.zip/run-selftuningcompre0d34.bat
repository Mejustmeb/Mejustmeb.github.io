@echo off
python "%~dp0selftuningcompre0d34.py" %*
pause
