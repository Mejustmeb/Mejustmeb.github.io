@echo off
python "%~dp0consequencelab3f85.py" %*
pause
