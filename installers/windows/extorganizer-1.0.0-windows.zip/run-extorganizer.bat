@echo off
python "%~dp0extorganizer.py" %*
pause
