@echo off
python "%~dp0resonantrenderer1b97.py" %*
pause
