@echo off
python "%~dp0livingbook73b4.py" %*
pause
