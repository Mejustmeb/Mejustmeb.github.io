@echo off
python "%~dp0resonantlanguage62b7.py" %*
pause
