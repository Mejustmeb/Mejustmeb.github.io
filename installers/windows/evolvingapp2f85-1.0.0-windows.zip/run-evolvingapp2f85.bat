@echo off
python "%~dp0evolvingapp2f85.py" %*
pause
