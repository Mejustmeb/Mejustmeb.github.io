@echo off
python "%~dp0freewillgamefc74.py" %*
pause
