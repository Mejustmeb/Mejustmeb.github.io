@echo off
python "%~dp0livingmusicengin729a.py" %*
pause
