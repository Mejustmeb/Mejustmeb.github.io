@echo off
python "%~dp0resonantlanguage9901.py" %*
pause
