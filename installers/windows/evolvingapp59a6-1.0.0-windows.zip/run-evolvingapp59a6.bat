@echo off
python "%~dp0evolvingapp59a6.py" %*
pause
