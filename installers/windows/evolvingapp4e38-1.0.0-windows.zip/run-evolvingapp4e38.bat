@echo off
python "%~dp0evolvingapp4e38.py" %*
pause
