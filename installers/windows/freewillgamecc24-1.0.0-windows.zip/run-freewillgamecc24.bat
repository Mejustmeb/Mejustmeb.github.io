@echo off
python "%~dp0freewillgamecc24.py" %*
pause
