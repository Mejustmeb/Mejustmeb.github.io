@echo off
python "%~dp0selftuningcompre4277.py" %*
pause
