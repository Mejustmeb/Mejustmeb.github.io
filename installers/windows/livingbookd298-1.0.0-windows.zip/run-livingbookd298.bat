@echo off
python "%~dp0livingbookd298.py" %*
pause
