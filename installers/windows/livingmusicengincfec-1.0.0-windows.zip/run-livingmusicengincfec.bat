@echo off
python "%~dp0livingmusicengincfec.py" %*
pause
