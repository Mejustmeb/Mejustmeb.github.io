@echo off
python "%~dp0livingmusicengin4740.py" %*
pause
