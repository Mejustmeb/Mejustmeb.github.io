@echo off
python "%~dp0livingmusicengin5bdd.py" %*
pause
