@echo off
python "%~dp0resonantlanguagea749.py" %*
pause
