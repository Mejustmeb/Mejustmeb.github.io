@echo off
python "%~dp0consequencelabf6d5.py" %*
pause
