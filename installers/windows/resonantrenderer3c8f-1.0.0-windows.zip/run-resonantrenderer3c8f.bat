@echo off
python "%~dp0resonantrenderer3c8f.py" %*
pause
