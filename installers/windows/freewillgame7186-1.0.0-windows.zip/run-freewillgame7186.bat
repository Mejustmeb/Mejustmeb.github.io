@echo off
python "%~dp0freewillgame7186.py" %*
pause
