@echo off
python "%~dp0consequencelabaee8.py" %*
pause
