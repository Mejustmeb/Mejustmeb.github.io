@echo off
python "%~dp0consequencelabb262.py" %*
pause
