@echo off
python "%~dp0freewillgame2c6b.py" %*
pause
