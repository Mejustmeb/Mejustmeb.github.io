@echo off
python "%~dp0selftuningcompre8665.py" %*
pause
