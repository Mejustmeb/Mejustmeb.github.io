@echo off
python "%~dp0consequencelab3d97.py" %*
pause
