@echo off
python "%~dp0livingmusicengin1074.py" %*
pause
