@echo off
python "%~dp0evolvingappf44e.py" %*
pause
