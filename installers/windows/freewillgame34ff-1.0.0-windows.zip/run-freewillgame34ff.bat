@echo off
python "%~dp0freewillgame34ff.py" %*
pause
