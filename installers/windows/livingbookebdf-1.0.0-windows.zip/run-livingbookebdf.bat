@echo off
python "%~dp0livingbookebdf.py" %*
pause
