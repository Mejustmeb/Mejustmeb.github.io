@echo off
python "%~dp0resonantlanguagee679.py" %*
pause
