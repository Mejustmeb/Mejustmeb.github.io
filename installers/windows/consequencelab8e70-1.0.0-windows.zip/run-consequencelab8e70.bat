@echo off
python "%~dp0consequencelab8e70.py" %*
pause
