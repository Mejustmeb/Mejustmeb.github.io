@echo off
python "%~dp0resonantrenderer7910.py" %*
pause
