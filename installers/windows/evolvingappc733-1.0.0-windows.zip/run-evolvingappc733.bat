@echo off
python "%~dp0evolvingappc733.py" %*
pause
