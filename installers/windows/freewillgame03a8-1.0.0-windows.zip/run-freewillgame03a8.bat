@echo off
python "%~dp0freewillgame03a8.py" %*
pause
