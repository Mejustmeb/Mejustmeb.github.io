@echo off
python "%~dp0livingbookb4e5.py" %*
pause
