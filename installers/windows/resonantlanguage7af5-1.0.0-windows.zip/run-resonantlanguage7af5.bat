@echo off
python "%~dp0resonantlanguage7af5.py" %*
pause
