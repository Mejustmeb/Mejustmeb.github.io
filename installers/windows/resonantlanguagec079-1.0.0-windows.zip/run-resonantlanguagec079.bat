@echo off
python "%~dp0resonantlanguagec079.py" %*
pause
