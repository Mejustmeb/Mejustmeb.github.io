@echo off
python "%~dp0resonantlanguage10bf.py" %*
pause
