@echo off
python "%~dp0resonantrendererc256.py" %*
pause
