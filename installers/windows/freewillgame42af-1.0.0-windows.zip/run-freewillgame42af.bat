@echo off
python "%~dp0freewillgame42af.py" %*
pause
