@echo off
python "%~dp0livingmusicenginf978.py" %*
pause
