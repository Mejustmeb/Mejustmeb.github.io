@echo off
python "%~dp0resonantrenderer61ae.py" %*
pause
