@echo off
python "%~dp0consequencelabc89a.py" %*
pause
