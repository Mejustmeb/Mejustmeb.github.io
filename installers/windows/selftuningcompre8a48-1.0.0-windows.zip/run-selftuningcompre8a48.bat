@echo off
python "%~dp0selftuningcompre8a48.py" %*
pause
