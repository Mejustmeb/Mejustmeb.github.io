@echo off
python "%~dp0resonantrendererd865.py" %*
pause
