@echo off
python "%~dp0resonantrenderer9a10.py" %*
pause
