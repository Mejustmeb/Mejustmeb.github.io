@echo off
python "%~dp0livingmusicengin4776.py" %*
pause
