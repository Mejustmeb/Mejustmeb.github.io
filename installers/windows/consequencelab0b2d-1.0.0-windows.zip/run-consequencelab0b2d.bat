@echo off
python "%~dp0consequencelab0b2d.py" %*
pause
