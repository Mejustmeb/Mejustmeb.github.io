@echo off
python "%~dp0resonantlanguage70e1.py" %*
pause
