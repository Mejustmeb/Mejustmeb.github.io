@echo off
python "%~dp0livingbook5e1f.py" %*
pause
