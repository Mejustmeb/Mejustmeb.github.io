@echo off
python "%~dp0resonantrenderer95db.py" %*
pause
