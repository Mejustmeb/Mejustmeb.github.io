@echo off
python "%~dp0selftuningcomprebd0b.py" %*
pause
