@echo off
python "%~dp0freewillgame2202.py" %*
pause
