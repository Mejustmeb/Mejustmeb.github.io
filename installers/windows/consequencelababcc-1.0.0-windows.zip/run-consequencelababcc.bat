@echo off
python "%~dp0consequencelababcc.py" %*
pause
