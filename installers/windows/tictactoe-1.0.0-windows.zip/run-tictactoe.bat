@echo off
python "%~dp0tictactoe.py" %*
pause
