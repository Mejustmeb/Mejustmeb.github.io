@echo off
python "%~dp0resonantlanguage034a.py" %*
pause
