@echo off
python "%~dp0freewillgame5087.py" %*
pause
