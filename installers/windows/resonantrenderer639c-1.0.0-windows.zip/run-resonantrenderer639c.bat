@echo off
python "%~dp0resonantrenderer639c.py" %*
pause
