@echo off
python "%~dp0selftuningcompre0e29.py" %*
pause
