@echo off
python "%~dp0evolvingapp3135.py" %*
pause
