@echo off
python "%~dp0livingmusicenginadf6.py" %*
pause
