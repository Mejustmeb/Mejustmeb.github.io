@echo off
python "%~dp0selftuningcompre0380.py" %*
pause
