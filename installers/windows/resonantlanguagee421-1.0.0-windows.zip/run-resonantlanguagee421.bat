@echo off
python "%~dp0resonantlanguagee421.py" %*
pause
