@echo off
python "%~dp0livingmusicenginad16.py" %*
pause
