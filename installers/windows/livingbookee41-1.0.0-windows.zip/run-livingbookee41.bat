@echo off
python "%~dp0livingbookee41.py" %*
pause
