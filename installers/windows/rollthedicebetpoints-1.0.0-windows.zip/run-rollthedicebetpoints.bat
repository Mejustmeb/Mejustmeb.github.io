@echo off
python "%~dp0rollthedicebetpoints.py" %*
pause
