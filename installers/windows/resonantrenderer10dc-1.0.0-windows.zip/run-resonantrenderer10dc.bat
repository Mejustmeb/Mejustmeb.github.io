@echo off
python "%~dp0resonantrenderer10dc.py" %*
pause
