@echo off
python "%~dp0duplicatefinder.py" %*
pause
