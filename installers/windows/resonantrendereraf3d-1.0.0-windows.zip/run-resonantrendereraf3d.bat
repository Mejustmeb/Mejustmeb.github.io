@echo off
python "%~dp0resonantrendereraf3d.py" %*
pause
