@echo off
python "%~dp0selftuningcompre3e54.py" %*
pause
