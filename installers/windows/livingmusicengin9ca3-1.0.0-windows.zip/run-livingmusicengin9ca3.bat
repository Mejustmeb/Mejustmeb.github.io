@echo off
python "%~dp0livingmusicengin9ca3.py" %*
pause
