@echo off
python "%~dp0livingbook66b6.py" %*
pause
