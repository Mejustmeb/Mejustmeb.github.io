@echo off
python "%~dp0livingbook971e.py" %*
pause
