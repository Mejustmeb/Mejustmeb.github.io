@echo off
python "%~dp0consequencelab432a.py" %*
pause
