@echo off
python "%~dp0consequencelabe711.py" %*
pause
