@echo off
python "%~dp0selftuningcompre0fe8.py" %*
pause
