@echo off
python "%~dp0resonantlanguage2eff.py" %*
pause
