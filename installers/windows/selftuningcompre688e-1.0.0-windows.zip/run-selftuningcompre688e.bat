@echo off
python "%~dp0selftuningcompre688e.py" %*
pause
