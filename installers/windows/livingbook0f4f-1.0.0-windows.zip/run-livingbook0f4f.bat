@echo off
python "%~dp0livingbook0f4f.py" %*
pause
