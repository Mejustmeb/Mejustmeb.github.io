@echo off
python "%~dp0selftuningcompre9f43.py" %*
pause
