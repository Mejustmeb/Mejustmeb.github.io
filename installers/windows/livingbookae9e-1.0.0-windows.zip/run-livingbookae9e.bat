@echo off
python "%~dp0livingbookae9e.py" %*
pause
