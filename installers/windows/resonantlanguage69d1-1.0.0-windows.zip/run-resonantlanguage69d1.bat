@echo off
python "%~dp0resonantlanguage69d1.py" %*
pause
