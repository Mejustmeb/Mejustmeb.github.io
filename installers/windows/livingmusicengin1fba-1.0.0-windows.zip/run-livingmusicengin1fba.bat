@echo off
python "%~dp0livingmusicengin1fba.py" %*
pause
