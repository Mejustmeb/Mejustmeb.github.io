@echo off
python "%~dp0selftuningcompref0a7.py" %*
pause
