@echo off
python "%~dp0livingbookcc91.py" %*
pause
