@echo off
python "%~dp0freewillgamea862.py" %*
pause
