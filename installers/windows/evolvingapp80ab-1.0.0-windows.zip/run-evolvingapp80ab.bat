@echo off
python "%~dp0evolvingapp80ab.py" %*
pause
