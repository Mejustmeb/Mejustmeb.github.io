@echo off
python "%~dp0livingbookb5b1.py" %*
pause
