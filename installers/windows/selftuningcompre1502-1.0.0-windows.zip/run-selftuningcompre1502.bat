@echo off
python "%~dp0selftuningcompre1502.py" %*
pause
