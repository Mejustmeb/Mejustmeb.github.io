@echo off
python "%~dp0livingbookae0c.py" %*
pause
