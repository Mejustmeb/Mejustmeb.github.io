@echo off
python "%~dp0livingmusicengin4a2a.py" %*
pause
