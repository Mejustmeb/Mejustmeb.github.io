@echo off
python "%~dp0livingbookb568.py" %*
pause
