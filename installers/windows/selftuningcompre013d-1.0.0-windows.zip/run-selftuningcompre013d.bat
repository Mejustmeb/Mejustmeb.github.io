@echo off
python "%~dp0selftuningcompre013d.py" %*
pause
