@echo off
python "%~dp0evolvingapp9f31.py" %*
pause
