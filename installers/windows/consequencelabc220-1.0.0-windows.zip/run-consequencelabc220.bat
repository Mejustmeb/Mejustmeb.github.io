@echo off
python "%~dp0consequencelabc220.py" %*
pause
