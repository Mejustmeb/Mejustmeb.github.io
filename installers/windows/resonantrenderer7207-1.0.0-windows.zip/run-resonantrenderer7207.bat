@echo off
python "%~dp0resonantrenderer7207.py" %*
pause
