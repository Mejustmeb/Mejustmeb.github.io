@echo off
python "%~dp0evolvingapp284a.py" %*
pause
