@echo off
python "%~dp0selftuningcompre5d8c.py" %*
pause
