@echo off
python "%~dp0consequencelabac63.py" %*
pause
