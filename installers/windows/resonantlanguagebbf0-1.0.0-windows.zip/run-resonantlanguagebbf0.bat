@echo off
python "%~dp0resonantlanguagebbf0.py" %*
pause
