@echo off
python "%~dp0resonantlanguage2fde.py" %*
pause
