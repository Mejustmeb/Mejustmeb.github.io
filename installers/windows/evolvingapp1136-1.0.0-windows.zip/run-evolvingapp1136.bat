@echo off
python "%~dp0evolvingapp1136.py" %*
pause
