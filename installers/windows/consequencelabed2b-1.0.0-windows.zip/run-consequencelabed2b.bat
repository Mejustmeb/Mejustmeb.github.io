@echo off
python "%~dp0consequencelabed2b.py" %*
pause
