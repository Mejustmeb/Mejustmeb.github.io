@echo off
python "%~dp0livingmusicenginca1e.py" %*
pause
