@echo off
python "%~dp0resonantlanguage11d4.py" %*
pause
