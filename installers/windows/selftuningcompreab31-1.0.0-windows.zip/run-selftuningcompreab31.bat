@echo off
python "%~dp0selftuningcompreab31.py" %*
pause
