@echo off
python "%~dp0freewillgame585e.py" %*
pause
