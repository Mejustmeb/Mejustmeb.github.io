@echo off
python "%~dp0resonantrenderer4051.py" %*
pause
