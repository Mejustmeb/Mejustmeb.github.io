@echo off
python "%~dp0freewillgame8181.py" %*
pause
