@echo off
python "%~dp0freewillgame787e.py" %*
pause
