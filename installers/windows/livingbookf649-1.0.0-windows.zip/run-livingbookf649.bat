@echo off
python "%~dp0livingbookf649.py" %*
pause
