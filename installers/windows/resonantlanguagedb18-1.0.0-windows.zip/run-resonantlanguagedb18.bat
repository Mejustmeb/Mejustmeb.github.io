@echo off
python "%~dp0resonantlanguagedb18.py" %*
pause
