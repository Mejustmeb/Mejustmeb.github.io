@echo off
python "%~dp0consequencelabe03e.py" %*
pause
