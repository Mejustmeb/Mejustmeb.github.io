@echo off
python "%~dp0consequencelab5954.py" %*
pause
