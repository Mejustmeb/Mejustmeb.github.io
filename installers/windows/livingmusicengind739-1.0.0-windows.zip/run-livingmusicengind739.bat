@echo off
python "%~dp0livingmusicengind739.py" %*
pause
