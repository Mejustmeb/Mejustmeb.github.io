@echo off
python "%~dp0evolvingapp3ec2.py" %*
pause
