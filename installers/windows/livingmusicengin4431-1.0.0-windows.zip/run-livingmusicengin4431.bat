@echo off
python "%~dp0livingmusicengin4431.py" %*
pause
