@echo off
python "%~dp0livingbook80f3.py" %*
pause
