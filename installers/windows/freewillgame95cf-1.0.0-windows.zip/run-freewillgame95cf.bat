@echo off
python "%~dp0freewillgame95cf.py" %*
pause
