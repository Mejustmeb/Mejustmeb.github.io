@echo off
python "%~dp0livingmusicengin2f89.py" %*
pause
