@echo off
python "%~dp0consequencelab50a6.py" %*
pause
