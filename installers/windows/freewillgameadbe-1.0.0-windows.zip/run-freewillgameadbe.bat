@echo off
python "%~dp0freewillgameadbe.py" %*
pause
