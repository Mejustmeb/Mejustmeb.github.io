@echo off
python "%~dp0resonantrendererae4e.py" %*
pause
