@echo off
python "%~dp0selftuningcompre0f55.py" %*
pause
