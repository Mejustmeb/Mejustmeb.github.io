@echo off
python "%~dp0resonantlanguage5fd1.py" %*
pause
