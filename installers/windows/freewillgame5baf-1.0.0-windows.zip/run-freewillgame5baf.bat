@echo off
python "%~dp0freewillgame5baf.py" %*
pause
