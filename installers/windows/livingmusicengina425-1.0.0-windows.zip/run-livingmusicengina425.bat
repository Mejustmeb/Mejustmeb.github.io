@echo off
python "%~dp0livingmusicengina425.py" %*
pause
