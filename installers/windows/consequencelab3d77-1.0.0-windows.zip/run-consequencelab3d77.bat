@echo off
python "%~dp0consequencelab3d77.py" %*
pause
