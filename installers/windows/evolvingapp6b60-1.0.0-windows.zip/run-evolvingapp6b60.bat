@echo off
python "%~dp0evolvingapp6b60.py" %*
pause
