@echo off
python "%~dp0resonantrendererf116.py" %*
pause
