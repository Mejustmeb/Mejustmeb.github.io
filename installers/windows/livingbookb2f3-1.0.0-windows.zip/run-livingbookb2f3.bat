@echo off
python "%~dp0livingbookb2f3.py" %*
pause
