@echo off
python "%~dp0consequencelaba862.py" %*
pause
