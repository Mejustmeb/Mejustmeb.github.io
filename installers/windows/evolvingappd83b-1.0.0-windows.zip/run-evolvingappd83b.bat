@echo off
python "%~dp0evolvingappd83b.py" %*
pause
