@echo off
python "%~dp0livingbookba3d.py" %*
pause
