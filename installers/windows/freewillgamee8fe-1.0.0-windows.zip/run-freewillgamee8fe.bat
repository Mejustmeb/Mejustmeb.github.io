@echo off
python "%~dp0freewillgamee8fe.py" %*
pause
