@echo off
python "%~dp0consequencelab0a1f.py" %*
pause
