@echo off
python "%~dp0evolvingapp32ac.py" %*
pause
