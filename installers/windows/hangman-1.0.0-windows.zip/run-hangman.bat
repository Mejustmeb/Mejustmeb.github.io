@echo off
python "%~dp0hangman.py" %*
pause
