@echo off
python "%~dp0evolvingapp6697.py" %*
pause
