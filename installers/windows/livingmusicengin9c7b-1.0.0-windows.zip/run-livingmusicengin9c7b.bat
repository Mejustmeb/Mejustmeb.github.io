@echo off
python "%~dp0livingmusicengin9c7b.py" %*
pause
