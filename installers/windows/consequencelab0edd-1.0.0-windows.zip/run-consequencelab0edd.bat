@echo off
python "%~dp0consequencelab0edd.py" %*
pause
