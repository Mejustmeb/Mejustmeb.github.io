@echo off
python "%~dp0freewillgameba80.py" %*
pause
