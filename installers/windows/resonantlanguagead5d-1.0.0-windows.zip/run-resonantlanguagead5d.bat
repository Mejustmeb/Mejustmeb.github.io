@echo off
python "%~dp0resonantlanguagead5d.py" %*
pause
