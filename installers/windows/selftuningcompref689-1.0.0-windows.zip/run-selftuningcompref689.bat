@echo off
python "%~dp0selftuningcompref689.py" %*
pause
