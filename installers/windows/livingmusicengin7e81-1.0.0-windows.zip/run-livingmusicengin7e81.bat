@echo off
python "%~dp0livingmusicengin7e81.py" %*
pause
