@echo off
python "%~dp0consequencelab880c.py" %*
pause
