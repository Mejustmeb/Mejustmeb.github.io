@echo off
python "%~dp0selftuningcompre4ae6.py" %*
pause
