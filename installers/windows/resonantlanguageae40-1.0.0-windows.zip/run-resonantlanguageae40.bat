@echo off
python "%~dp0resonantlanguageae40.py" %*
pause
