@echo off
python "%~dp0resonantlanguagee912.py" %*
pause
