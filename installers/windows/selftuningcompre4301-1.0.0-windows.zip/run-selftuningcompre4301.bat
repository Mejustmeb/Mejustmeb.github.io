@echo off
python "%~dp0selftuningcompre4301.py" %*
pause
