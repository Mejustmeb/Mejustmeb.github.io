#!/usr/bin/env python3
"""Free-Will Game 1DFA - a adventure game by Echo."""
import random

ITEMS = ['seemed', 'inactivity', 'darkred', 'Zinc', 'ibex']

def play(seed=None):
    """Run one hunt. Returns True if the goal is found."""
    rng = random.Random(seed)
    goal = rng.choice(ITEMS)
    print("=== Free-Will Game 1DFA ===")
    print("You are Ibex, exploring Villa Santa Rita.")
    print("Theme: A game engine that is aware of its own history and grows fro")
    print("Goal: find the " + goal + ".")
    bag = []
    for i in range(3):
        found = rng.choice(ITEMS)
        bag.append(found)
        print("  spot " + str(i + 1) + ": " + found)
    if goal in bag:
        print("VICTORY - you found the " + goal + "!")
        return True
    print("The " + goal + " eluded you.")
    return False

if __name__ == "__main__":
    play()
